import hashlib
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from matplotlib.figure import Figure
from pypdf import PdfReader

from analysis_report import build_analysis_pdf, sha256_file


class AnalysisReportTests(unittest.TestCase):
    def test_sha256_matches_source_bytes(self):
        with TemporaryDirectory() as folder:
            path = Path(folder) / "source.csv"
            path.write_bytes(b"TDS source data\n")
            self.assertEqual(sha256_file(path), hashlib.sha256(path.read_bytes()).hexdigest())

    def test_chinese_pdf_is_parseable_and_multipage(self):
        with TemporaryDirectory() as folder:
            figure = Figure(figsize=(4, 3)); figure.subplots().plot([30, 100], [1e-12, 2e-12])
            path = Path(folder) / "report.pdf"
            build_analysis_pdf(path, app_name="TDS Plotter", app_version="test", project_name="测试项目",
                               sources=[{"filename": "sample.csv", "sha256": "a" * 64, "points": 2, "mz_count": 1}],
                               settings={"smoothing": "None"}, plot_pages=[{"label": "m/z 2", "figure": figure}],
                               smoothing_comparisons=[], fit_sessions=[])
            reader = PdfReader(path)
            self.assertGreaterEqual(len(reader.pages), 3)
            self.assertGreater(path.stat().st_size, 10000)


if __name__ == "__main__":
    unittest.main()
