from __future__ import annotations

import csv
import re
from dataclasses import dataclass
from pathlib import Path


ENCODINGS = ("utf-8-sig", "utf-8", "gb18030", "shift_jis", "cp1252")
DELIMITERS = (",", ";", "\t")


class ColumnMappingRequired(ValueError):
    def __init__(self, message: str, layout: "CSVLayout"):
        super().__init__(message)
        self.layout = layout


@dataclass
class CSVLayout:
    path: str
    text: str
    encoding: str
    delimiter: str
    rows: list[list[str]]
    header_index: int
    headers: list[str]


def decode_text(path: str | Path) -> tuple[str, str]:
    raw = Path(path).read_bytes()
    for encoding in ENCODINGS:
        try:
            return raw.decode(encoding), encoding
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace"), "utf-8 (replacement characters)"


def detect_delimiter(text: str) -> str:
    useful = "\n".join(line for line in text.splitlines()[:80] if line.strip())
    try:
        return csv.Sniffer().sniff(useful, delimiters="".join(DELIMITERS)).delimiter
    except csv.Error:
        scores = {delimiter: sum(line.count(delimiter) for line in useful.splitlines()) for delimiter in DELIMITERS}
        return max(scores, key=scores.get)


def _temperature_header(name: str) -> bool:
    compact = re.sub(r"[\s_\-]+", "", name.lower())
    return bool(re.search(r"temperature|temp|温度", compact))


def canonical_mz(name: str) -> str | None:
    compact = name.strip().lower().replace("／", "/")
    match = re.search(r"(?:m\s*/?\s*z|mass|amu)\s*[:=_-]?\s*(\d+(?:\.\d+)?)", compact)
    if not match:
        return None
    value = float(match.group(1))
    return f"m/z {int(value)}" if value.is_integer() else f"m/z {value:g}"


def inspect_csv(path: str | Path) -> CSVLayout:
    text, encoding = decode_text(path)
    delimiter = detect_delimiter(text)
    rows = [[cell.strip() for cell in row] for row in csv.reader(text.splitlines(), delimiter=delimiter)]
    candidates = []
    for index, row in enumerate(rows[:120]):
        nonempty = [cell for cell in row if cell]
        if len(nonempty) < 2:
            continue
        score = len(nonempty) + 10 * any(_temperature_header(cell) for cell in row) + 8 * sum(canonical_mz(cell) is not None for cell in row)
        candidates.append((score, index))
    # Keep the earliest row when scores tie; data rows often have the same
    # field count as their header.
    header_index = max(candidates, key=lambda item: item[0], default=(0, 0))[1]
    headers = rows[header_index] if rows else []
    return CSVLayout(str(Path(path).resolve()), text, encoding, delimiter, rows, header_index, headers)


def automatic_mapping(layout: CSVLayout) -> dict | None:
    temperature = next((header for header in layout.headers if _temperature_header(header)), None)
    mz = {header: canonical_mz(header) for header in layout.headers if canonical_mz(header)}
    time = next((header for header in layout.headers if re.search(r"(^|\W)time($|\W)|时间", header, re.I)), None)
    if temperature and mz:
        return {"header_index": layout.header_index, "temperature": temperature, "time": time, "mz": mz}
    return None


def template_mapping(layout: CSVLayout, templates: list[dict]) -> tuple[dict | None, str | None]:
    available = set(layout.headers)
    for template in templates:
        temperature = template.get("temperature")
        mz = template.get("mz", {})
        if temperature in available and mz and set(mz).issubset(available):
            return {"header_index": layout.header_index, "temperature": temperature,
                    "time": template.get("time") if template.get("time") in available else None, "mz": dict(mz)}, template.get("name")
    return None, None


def parse_number(value: str, decimal_comma: bool) -> float:
    text = str(value or "").strip()
    if not text or text.lower() in {"na", "n/a", "nan", "null", "-"}:
        return float("nan")
    if decimal_comma and "," in text and "." not in text:
        text = text.replace(",", ".")
    return float(text)
