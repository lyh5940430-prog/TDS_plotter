import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np

from matplotlib.figure import Figure
from PIL import Image

from tds_plotter import (PlotSettings, TDSData, apply_data_limits, apply_y_policy, automatic_legend_font_size,
                         automatic_title_font_size, export_figure, format_plot_text, parse_tds_csv,
                         positive_floor, sample_curve_color, smooth_signal)


SAMPLE = """MID Data C:\\data\\sample.mfd
April 09 2026 13:27:42

No.,Time[s],Temperature1[C],Temperature2[C],m/z 2,m/z 18
1,1,30,31,1e-12,-1e-14
2,2,40,32,2e-12,2e-13
3,3,50,33,3e-12,3e-13
4,4,60,34,4e-12,4e-13
5,5,70,35,5e-12,5e-13
"""


class TDSPlotterTests(unittest.TestCase):
    def test_sample_color_can_override_or_use_palette(self):
        sample = TDSData("a.csv", "A", [], {"Temperature1[C]": [1], "m/z 2": [1]}, ["m/z 2"])
        self.assertEqual(sample_curve_color(sample, 1), "#D55E00")
        sample.plot_color = "#123456"
        self.assertEqual(sample_curve_color(sample, 1), "#123456")
        sample.plot_color = "not-a-color"
        self.assertEqual(sample_curve_color(sample, 1), "#D55E00")

    def test_automatic_fonts_and_templates(self):
        figure = Figure(figsize=(7.2, 5.2))
        self.assertGreater(automatic_title_font_size(figure, "Short"), automatic_title_font_size(figure, "A" * 100))
        self.assertGreater(automatic_legend_font_size(figure, ["A"]), automatic_legend_font_size(figure, ["Long sample name"] * 8))
        self.assertEqual(format_plot_text("{sample}: {mz}", "", "S1", "m/z 18"), "S1: m/z 18")

    def test_parser_finds_metadata_temperature_and_mz(self):
        with TemporaryDirectory() as folder:
            path = Path(folder) / "sample.csv"
            path.write_text(SAMPLE, encoding="utf-8")
            data = parse_tds_csv(path)
            self.assertEqual(data.mz_columns, ["m/z 2", "m/z 18"])
            self.assertEqual(data.temperature.tolist(), [30, 40, 50, 60, 70])
            self.assertEqual(len(data.metadata), 3)

    def test_log_floor_uses_one_decade_below_manual_y_min(self):
        settings = PlotSettings(auto_y=False, y_min=1e-15, y_max=1e-8)
        floor = positive_floor(settings, [np.array([-1.0, 1e-12])])
        transformed, replaced = apply_y_policy(np.array([-1.0, 0.0, 1e-12]), settings, floor)
        self.assertAlmostEqual(floor, 1e-16)
        self.assertEqual(replaced, 2)
        np.testing.assert_allclose(transformed[:2], [1e-16, 1e-16])

    def test_smoothing_preserves_length(self):
        values = np.array([1.0, 2.0, 9.0, 2.0, 1.0, 2.0, 1.0])
        for method in ["Savitzky-Golay", "Moving average", "Gaussian", "None"]:
            settings = PlotSettings(smoothing=method, window=5, polyorder=2)
            self.assertEqual(len(smooth_signal(values, settings)), len(values))

    def test_smoothing_preserves_missing_gap_without_bridging(self):
        values = np.array([1.0, 2.0, 3.0, np.nan, 5.0, 6.0, 7.0])
        result = smooth_signal(values, PlotSettings(smoothing="Moving average", window=3))
        self.assertTrue(np.isnan(result[3]))
        self.assertTrue(np.all(np.isfinite(result[[0, 1, 2, 4, 5, 6]])))

    def test_semicolon_decimal_comma_and_missing_value(self):
        content = "说明\nTime[s];Temp C;Mass 18\n0;30,5;1,0e-12\n1;40,5;\n2;50,5;3,0e-12\n"
        with TemporaryDirectory() as folder:
            path = Path(folder) / "europe.csv"; path.write_text(content, encoding="utf-8")
            data = parse_tds_csv(path)
            self.assertEqual(data.delimiter, "分号")
            self.assertEqual(data.temperature.tolist(), [30.5, 40.5, 50.5])
            self.assertTrue(np.isnan(data.signal("m/z 18")[1]))
            self.assertTrue(data.quality_warnings)

    def test_saved_template_maps_generic_signal_column(self):
        content = "Experiment\nSeconds\tFurnace\tSignal A\n0\t30\t1e-12\n1\t40\t2e-12\n"
        template = {"name": "Instrument A", "temperature": "Furnace", "time": "Seconds", "mz": {"Signal A": "m/z 2"}}
        with TemporaryDirectory() as folder:
            path = Path(folder) / "generic.tsv"; path.write_text(content, encoding="utf-8")
            data = parse_tds_csv(path, templates=[template])
            self.assertEqual(data.import_template, "Instrument A")
            self.assertEqual(data.mz_columns, ["m/z 2"])

    def test_png_export_is_opaque_rgb_and_has_manifest(self):
        with TemporaryDirectory() as folder:
            path = Path(folder) / "figure.png"
            figure = Figure(figsize=(2, 1), dpi=100)
            figure.subplots().plot([0, 1], [1, 2])
            export_figure(figure, path, {"test": True})
            with Image.open(path) as image:
                self.assertEqual(image.mode, "RGB")
                self.assertGreaterEqual(image.info["dpi"][0], 600.0)
            self.assertTrue(path.with_suffix(".png.json").exists())

    def test_auto_limits_use_temperature_data_and_ignore_log_floor(self):
        settings = PlotSettings(auto_x=True, auto_y=True, y_mode="Log axis")
        x = np.array([28.9, 100.0, 720.0])
        source = np.array([-1.0, 1e-12, 1e-10])
        plotted = np.array([1e-16, 1e-12, 1e-10])
        figure = Figure()
        ax = figure.subplots()
        ax.set_yscale("log")
        apply_data_limits(ax, settings, [x], [source], [plotted])
        self.assertAlmostEqual(ax.get_xlim()[0], 28.9)
        self.assertAlmostEqual(ax.get_xlim()[1], 720.0)
        self.assertGreater(ax.get_ylim()[0], 1e-14)


if __name__ == "__main__":
    unittest.main()
