from __future__ import annotations

from dataclasses import asdict, dataclass, field
import math
from typing import Callable

import numpy as np
from scipy import sparse
from scipy.optimize import least_squares
from scipy.signal import find_peaks, savgol_filter
from scipy.sparse.linalg import spsolve


PEAK_TYPES = ("Gaussian", "Lorentzian", "Pseudo-Voigt")
BASELINE_TYPES = ("None", "Constant", "Linear", "Asymmetric least squares")
WEIGHT_TYPES = ("None", "Relative", "Poisson-like", "Custom")


@dataclass
class PeakSpec:
    center: float
    height: float
    fwhm: float
    locked_center: bool = False
    locked_height: bool = False
    locked_fwhm: bool = False
    eta: float = 0.5


@dataclass
class FitConfig:
    peak_type: str = "Pseudo-Voigt"
    baseline_type: str = "None"
    weighting: str = "None"
    custom_weight_floor: float = 0.01
    center_tolerance: float | None = None
    als_lambda: float = 1e6
    als_asymmetry: float = 0.01
    max_nfev: int = 30000


@dataclass
class PeakResult:
    index: int
    center: float
    height: float
    fwhm: float
    area: float
    eta: float | None
    center_se: float | None = None
    height_se: float | None = None
    fwhm_se: float | None = None
    area_se: float | None = None
    center_ci95: tuple[float, float] | None = None
    height_ci95: tuple[float, float] | None = None
    fwhm_ci95: tuple[float, float] | None = None
    area_ci95: tuple[float, float] | None = None


@dataclass
class FitResult:
    success: bool
    message: str
    config: FitConfig
    peaks: list[PeakResult]
    x: np.ndarray
    observed: np.ndarray
    total_fit: np.ndarray
    baseline: np.ndarray
    components: list[np.ndarray]
    residual: np.ndarray
    r_squared: float
    adjusted_r_squared: float
    rmse: float
    aic: float
    bic: float
    n_parameters: int
    covariance_warning: str | None = None
    bootstrap_samples: int = 0
    diagnostics: list[str] = field(default_factory=list)

    def summary_dict(self) -> dict:
        return {
            "success": self.success,
            "message": self.message,
            "config": asdict(self.config),
            "peaks": [asdict(peak) for peak in self.peaks],
            "statistics": {
                "r_squared": self.r_squared,
                "adjusted_r_squared": self.adjusted_r_squared,
                "rmse": self.rmse,
                "aic": self.aic,
                "bic": self.bic,
                "n_parameters": self.n_parameters,
                "bootstrap_samples": self.bootstrap_samples,
                "covariance_warning": self.covariance_warning,
                "diagnostics": self.diagnostics,
            },
        }


def gaussian(x: np.ndarray, center: float, height: float, fwhm: float) -> np.ndarray:
    sigma = max(fwhm, np.finfo(float).eps) / (2.0 * math.sqrt(2.0 * math.log(2.0)))
    return height * np.exp(-0.5 * ((x - center) / sigma) ** 2)


def lorentzian(x: np.ndarray, center: float, height: float, fwhm: float) -> np.ndarray:
    gamma = max(fwhm, np.finfo(float).eps) / 2.0
    return height / (1.0 + ((x - center) / gamma) ** 2)


def pseudo_voigt(x: np.ndarray, center: float, height: float, fwhm: float, eta: float) -> np.ndarray:
    return eta * lorentzian(x, center, height, fwhm) + (1.0 - eta) * gaussian(x, center, height, fwhm)


def peak_curve(x: np.ndarray, peak_type: str, center: float, height: float, fwhm: float, eta: float = 0.5) -> np.ndarray:
    if peak_type == "Gaussian":
        return gaussian(x, center, height, fwhm)
    if peak_type == "Lorentzian":
        return lorentzian(x, center, height, fwhm)
    if peak_type == "Pseudo-Voigt":
        return pseudo_voigt(x, center, height, fwhm, eta)
    raise ValueError(f"Unknown peak type: {peak_type}")


def peak_area(peak_type: str, height: float, fwhm: float, eta: float = 0.5) -> float:
    gaussian_area = height * fwhm * math.sqrt(math.pi / (4.0 * math.log(2.0)))
    lorentz_area = height * math.pi * fwhm / 2.0
    if peak_type == "Gaussian":
        return gaussian_area
    if peak_type == "Lorentzian":
        return lorentz_area
    return (1.0 - eta) * gaussian_area + eta * lorentz_area


def asymmetric_least_squares(y: np.ndarray, lam: float = 1e6, p: float = 0.01, iterations: int = 20) -> np.ndarray:
    length = len(y)
    if length < 3:
        return np.zeros_like(y)
    difference = sparse.diags([1.0, -2.0, 1.0], [0, 1, 2], shape=(length - 2, length))
    weights = np.ones(length)
    for _ in range(iterations):
        weight_matrix = sparse.spdiags(weights, 0, length, length)
        system = (weight_matrix + lam * difference.T @ difference).tocsc()
        baseline = spsolve(system, weights * y)
        weights = p * (y > baseline) + (1.0 - p) * (y <= baseline)
    return np.asarray(baseline)


def detect_peaks(
    x: np.ndarray,
    y: np.ndarray,
    prominence_percent: float = 3.0,
    min_distance_temperature: float = 20.0,
    min_width_temperature: float = 5.0,
    max_peaks: int | None = None,
) -> list[PeakSpec]:
    x, y = _clean_xy(x, y)
    if len(x) < 5:
        return []
    step = float(np.median(np.diff(x)))
    step = max(abs(step), np.finfo(float).eps)
    window = min(11, len(y) if len(y) % 2 else len(y) - 1)
    window = max(5, window)
    # Remove only a slowly varying baseline for peak detection. The fit itself
    # still uses the unmodified linear-current observations.
    detection_baseline = asymmetric_least_squares(y, lam=1e7, p=0.01, iterations=15)
    corrected = np.maximum(y - detection_baseline, 0.0)
    smooth = savgol_filter(corrected, window, min(3, window - 1), mode="interp") if len(y) >= window else corrected
    span = float(np.max(smooth) - np.min(smooth))
    prominence = max(span * prominence_percent / 100.0, np.finfo(float).eps)
    distance = max(1, round(min_distance_temperature / step))
    width = max(1, min_width_temperature / step)
    indices, properties = find_peaks(smooth, prominence=prominence, distance=distance, width=width)
    ranked = sorted(indices, key=lambda i: smooth[i], reverse=True)
    if max_peaks is not None and max_peaks > 0:
        ranked = ranked[:max_peaks]
    ranked.sort(key=lambda i: x[i])
    specs = []
    for index in ranked:
        half = max(float(smooth[index] - np.min(smooth)) / 2.0, np.finfo(float).eps)
        left = index
        while left > 0 and smooth[left] > np.min(smooth) + half:
            left -= 1
        right = index
        while right < len(smooth) - 1 and smooth[right] > np.min(smooth) + half:
            right += 1
        fwhm = max(float(x[right] - x[left]), min_width_temperature, step * 2)
        specs.append(PeakSpec(float(x[index]), max(float(corrected[index]), span * 0.01), fwhm))
    return specs


def suggest_complete_peak_range(x: np.ndarray, y: np.ndarray) -> tuple[float, float, list[str]]:
    """Suggest a range that excludes strongly rising, incomplete edge features."""
    x, y = _clean_xy(x, y)
    if len(x) < 15:
        return float(np.min(x)), float(np.max(x)), []
    window = min(31, len(y) if len(y) % 2 else len(y) - 1)
    window = max(5, window)
    smooth = savgol_filter(y, window, min(3, window - 1), mode="interp")
    span = max(float(np.ptp(smooth)), np.finfo(float).eps)
    x_span = float(np.ptp(x))
    low, high = float(np.min(x)), float(np.max(x))
    notes: list[str] = []

    minima, _ = find_peaks(-smooth, distance=max(3, len(x) // 30))
    right_minima = [index for index in minima if index >= int(len(x) * 0.40)]
    tail_slope = float(np.mean(np.diff(smooth[-max(5, len(x) // 30):])))
    if right_minima:
        index = right_minima[-1]
        rise = float(smooth[-1] - smooth[index])
        if rise > span * 0.15 and tail_slope > 0:
            high = min(float(x[-1]), float(x[index] + x_span * 0.03))
            notes.append(f"右边界信号仍明显上升，疑似未测完整峰；建议拟合上限约为 {high:.1f} °C。")

    left_maxima, _ = find_peaks(smooth, distance=max(3, len(x) // 30), prominence=span * 0.002)
    left_candidates = [index for index in left_maxima if index <= int(len(x) * 0.35)]
    head_slope = float(np.mean(np.diff(smooth[:max(5, len(x) // 30)])))
    if left_candidates:
        index = left_candidates[0]
        drop = float(smooth[0] - smooth[index])
        if drop > span * 0.15 and head_slope < 0:
            low = max(float(x[0]), float(x[index] - x_span * 0.03))
            notes.append(f"左边界信号仍明显下降，疑似未测完整峰；建议拟合下限约为 {low:.1f} °C。")
    return low, high, notes


def _clean_xy(x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y)
    x, y = x[mask], y[mask]
    order = np.argsort(x)
    return x[order], y[order]


def _weights(y: np.ndarray, config: FitConfig) -> np.ndarray:
    magnitude = np.abs(y)
    positive = magnitude[magnitude > 0]
    reference = float(np.median(positive)) if positive.size else 1.0
    floor = max(float(np.max(magnitude)) * config.custom_weight_floor, reference * 1e-6, np.finfo(float).eps)
    if config.weighting == "None":
        result = np.ones_like(y)
    elif config.weighting == "Relative":
        result = 1.0 / np.maximum(magnitude, floor)
    elif config.weighting == "Poisson-like":
        result = 1.0 / np.sqrt(np.maximum(magnitude, floor))
    elif config.weighting == "Custom":
        result = 1.0 / np.maximum(magnitude, floor)
    else:
        raise ValueError(f"Unknown weighting: {config.weighting}")
    return result / np.median(result)


def fit_peaks(x: np.ndarray, y: np.ndarray, specs: list[PeakSpec], config: FitConfig) -> FitResult:
    x, y = _clean_xy(x, y)
    if len(x) < 5:
        raise ValueError("At least five valid data points are required.")
    if not specs:
        raise ValueError("At least one peak is required.")
    if config.peak_type not in PEAK_TYPES or config.baseline_type not in BASELINE_TYPES or config.weighting not in WEIGHT_TYPES:
        raise ValueError("Unsupported fitting option.")
    x_span = max(float(np.ptp(x)), np.finfo(float).eps)
    y_span = max(float(np.ptp(y)), float(np.max(np.abs(y))) * 1e-6, np.finfo(float).eps)

    fixed_baseline = asymmetric_least_squares(y, config.als_lambda, config.als_asymmetry) if config.baseline_type == "Asymmetric least squares" else np.zeros_like(y)
    baseline_guess = float(np.percentile(y, 5))
    parameters: list[float] = []
    lower: list[float] = []
    upper: list[float] = []
    descriptors: list[tuple] = []

    def add(value: float, low: float, high: float, descriptor: tuple) -> None:
        parameters.append(float(np.clip(value, low + np.finfo(float).eps, high - np.finfo(float).eps)))
        lower.append(low)
        upper.append(high)
        descriptors.append(descriptor)

    if config.baseline_type == "Constant":
        add(baseline_guess, float(np.min(y) - y_span), float(np.max(y)), ("baseline", "constant"))
    elif config.baseline_type == "Linear":
        add(baseline_guess, float(np.min(y) - y_span), float(np.max(y)), ("baseline", "intercept"))
        add(0.0, -10 * y_span / x_span, 10 * y_span / x_span, ("baseline", "slope"))

    initial = [PeakSpec(**asdict(spec)) for spec in specs]
    for i, peak in enumerate(initial):
        sample_step = max(float(np.median(np.diff(x))), np.finfo(float).eps)
        tolerance = config.center_tolerance if config.center_tolerance is not None else max(peak.fwhm, sample_step * 5)
        center_low, center_high = max(float(np.min(x)), peak.center - tolerance), min(float(np.max(x)), peak.center + tolerance)
        if not peak.locked_center:
            add(peak.center, center_low, center_high, ("peak", i, "center"))
        if not peak.locked_height:
            add(max(peak.height, y_span * 1e-6), 0.0, max(float(np.max(y) - np.min(y)) * 10, y_span * 10), ("peak", i, "height"))
        if not peak.locked_fwhm:
            width_low = max(sample_step * 0.5, peak.fwhm / 5.0)
            width_high = min(x_span, max(peak.fwhm * 5.0, sample_step * 3.0))
            add(max(peak.fwhm, sample_step), width_low, width_high, ("peak", i, "fwhm"))
        if config.peak_type == "Pseudo-Voigt":
            add(peak.eta, 0.0, 1.0, ("peak", i, "eta"))

    def unpack(vector: np.ndarray) -> tuple[list[PeakSpec], np.ndarray]:
        peaks = [PeakSpec(**asdict(spec)) for spec in initial]
        constant, slope = 0.0, 0.0
        for value, descriptor in zip(vector, descriptors):
            if descriptor[0] == "baseline":
                if descriptor[1] in {"constant", "intercept"}:
                    constant = value
                else:
                    slope = value
            else:
                setattr(peaks[descriptor[1]], descriptor[2], float(value))
        if config.baseline_type == "Asymmetric least squares":
            baseline = fixed_baseline
        elif config.baseline_type == "None":
            baseline = np.zeros_like(x)
        else:
            baseline = constant + slope * (x - np.mean(x))
        return peaks, baseline

    def evaluate(vector: np.ndarray) -> tuple[np.ndarray, list[np.ndarray], np.ndarray, list[PeakSpec]]:
        peaks, baseline = unpack(vector)
        components = [peak_curve(x, config.peak_type, p.center, p.height, p.fwhm, p.eta) for p in peaks]
        total = baseline + np.sum(components, axis=0)
        return total, components, baseline, peaks

    weights = _weights(y, config)
    residual_scale = y_span
    optimum = least_squares(lambda vector: (evaluate(vector)[0] - y) * weights / residual_scale, parameters, bounds=(lower, upper), max_nfev=config.max_nfev, x_scale="jac")
    total, components, baseline, fitted_specs = evaluate(optimum.x)
    residual = y - total
    n, k = len(y), len(optimum.x)
    rss = max(float(np.sum(residual**2)), np.finfo(float).tiny)
    tss = float(np.sum((y - np.mean(y)) ** 2))
    r2 = 1.0 - rss / tss if tss > 0 else float("nan")
    adjusted = 1.0 - (1.0 - r2) * (n - 1) / max(n - k - 1, 1) if np.isfinite(r2) else float("nan")
    rmse = math.sqrt(rss / n)
    aic = n * math.log(rss / n) + 2 * k
    bic = n * math.log(rss / n) + k * math.log(n)

    standard_errors = np.full(k, np.nan)
    covariance_warning = None
    try:
        jacobian = optimum.jac
        variance = float(np.sum((residual * weights / residual_scale) ** 2)) / max(n - k, 1)
        column_norms = np.linalg.norm(jacobian, axis=0)
        parameter_scales = 1.0 / np.where(column_norms > 0, column_norms, 1.0)
        normalized_jacobian = jacobian * parameter_scales
        covariance_scaled = np.linalg.pinv(normalized_jacobian.T @ normalized_jacobian) * variance
        covariance = parameter_scales[:, None] * covariance_scaled * parameter_scales[None, :]
        standard_errors = np.sqrt(np.maximum(np.diag(covariance), 0.0))
        if np.linalg.cond(normalized_jacobian.T @ normalized_jacobian) > 1e10:
            covariance_warning = "参数协方差病态，快速置信区间可能不可靠；请检查重叠峰、边界峰和过宽峰，必要时使用 Bootstrap。"
    except Exception as exc:
        covariance_warning = f"无法计算参数协方差：{exc}"

    error_lookup = {descriptor: standard_errors[i] for i, descriptor in enumerate(descriptors)}
    peak_results = []
    for i, peak in enumerate(fitted_specs):
        center_se = float(error_lookup.get(("peak", i, "center"), 0.0))
        height_se = float(error_lookup.get(("peak", i, "height"), 0.0))
        fwhm_se = float(error_lookup.get(("peak", i, "fwhm"), 0.0))
        eta_se = float(error_lookup.get(("peak", i, "eta"), 0.0))
        area = peak_area(config.peak_type, peak.height, peak.fwhm, peak.eta)
        # First-order propagation, including eta for pseudo-Voigt.
        derivatives = [
            (peak_area(config.peak_type, peak.height + max(abs(peak.height) * 1e-6, 1e-30), peak.fwhm, peak.eta) - area) / max(abs(peak.height) * 1e-6, 1e-30),
            (peak_area(config.peak_type, peak.height, peak.fwhm + max(abs(peak.fwhm) * 1e-6, 1e-9), peak.eta) - area) / max(abs(peak.fwhm) * 1e-6, 1e-9),
            (peak_area(config.peak_type, peak.height, peak.fwhm, min(1.0, peak.eta + 1e-6)) - area) / 1e-6 if config.peak_type == "Pseudo-Voigt" else 0.0,
        ]
        area_se = math.sqrt(sum(value**2 for value in [derivatives[0] * height_se, derivatives[1] * fwhm_se, derivatives[2] * eta_se]))
        ci = lambda value, se: (value - 1.96 * se, value + 1.96 * se) if np.isfinite(se) else None
        peak_results.append(PeakResult(i + 1, peak.center, peak.height, peak.fwhm, area, peak.eta if config.peak_type == "Pseudo-Voigt" else None, center_se, height_se, fwhm_se, area_se, ci(peak.center, center_se), ci(peak.height, height_se), ci(peak.fwhm, fwhm_se), ci(area, area_se)))

    diagnostics = []
    edge_margin = max(float(np.median(np.diff(x))) * 2.0, x_span * 0.01)
    for peak in peak_results:
        if peak.center - float(np.min(x)) <= edge_margin or float(np.max(x)) - peak.center <= edge_margin:
            diagnostics.append(f"Peak {peak.index} 位于拟合区间边界，峰位、FWHM 和面积不可可靠确定。")
            peak.center_ci95 = None
            peak.height_ci95 = None
            peak.fwhm_ci95 = None
            peak.area_ci95 = None
        if peak.fwhm >= x_span * 0.45:
            diagnostics.append(f"Peak {peak.index} 的 FWHM 占拟合区间 {peak.fwhm / x_span:.0%}，可能正在代替背景。")
    residual_ratio = float(np.max(np.abs(residual))) / y_span
    if residual_ratio > 0.10:
        diagnostics.append(f"最大残差为信号跨度的 {residual_ratio:.1%}，模型仍有明显未解释结构。")
    _, _, boundary_notes = suggest_complete_peak_range(x, y)
    diagnostics.extend(boundary_notes)
    if covariance_warning:
        diagnostics.append(covariance_warning)
    return FitResult(optimum.success, optimum.message, config, peak_results, x, y, total, baseline, components, residual, r2, adjusted, rmse, aic, bic, k, covariance_warning, 0, diagnostics)


def suggest_peak_from_residual(result: FitResult, min_distance_temperature: float = 20.0, min_width_temperature: float = 5.0) -> PeakSpec | None:
    """Suggest the strongest unresolved positive residual peak."""
    positive = np.maximum(result.residual, 0.0)
    if not np.any(positive > 0):
        return None
    candidates = detect_peaks(
        result.x,
        positive,
        prominence_percent=2.0,
        min_distance_temperature=min_distance_temperature,
        min_width_temperature=min_width_temperature,
        max_peaks=None,
    )
    if not candidates:
        return None
    existing = np.asarray([peak.center for peak in result.peaks])
    separated = [peak for peak in candidates if not existing.size or float(np.min(np.abs(existing - peak.center))) >= min_distance_temperature]
    if not separated:
        return None
    return max(separated, key=lambda peak: peak.height)


def best_residual_peak_trial(
    result: FitResult,
    min_distance_temperature: float = 20.0,
    min_width_temperature: float = 5.0,
) -> tuple[PeakSpec | None, FitResult | None, float]:
    """Fit several residual candidates and return the largest valid BIC improvement."""
    positive = np.maximum(result.residual, 0.0)
    candidates = detect_peaks(
        result.x,
        positive,
        prominence_percent=0.5,
        min_distance_temperature=min_distance_temperature,
        min_width_temperature=min_width_temperature,
        max_peaks=None,
    )
    x_span = float(np.ptp(result.x))
    edge_margin = x_span * 0.03
    existing = np.asarray([peak.center for peak in result.peaks])
    base_specs = [PeakSpec(p.center, p.height, p.fwhm, eta=p.eta or 0.5) for p in result.peaks]
    best: tuple[PeakSpec | None, FitResult | None, float] = (None, None, float("-inf"))
    for candidate in candidates:
        if candidate.center - float(np.min(result.x)) < edge_margin or float(np.max(result.x)) - candidate.center < edge_margin:
            continue
        if candidate.fwhm > x_span * 0.50:
            continue
        if existing.size and float(np.min(np.abs(existing - candidate.center))) < min_distance_temperature:
            continue
        try:
            trial = fit_peaks(result.x, result.observed, base_specs + [candidate], result.config)
        except Exception:
            continue
        if any("边界" in item for item in trial.diagnostics):
            continue
        improvement = result.bic - trial.bic
        if improvement > best[2]:
            best = (candidate, trial, improvement)
    return best


def bootstrap_confidence(result: FitResult, specs: list[PeakSpec], samples: int = 200, seed: int = 20260805, progress: Callable[[int, int], None] | None = None) -> FitResult:
    rng = np.random.default_rng(seed)
    successful: list[list[tuple[float, float, float, float]]] = []
    base_specs = [PeakSpec(p.center, p.height, p.fwhm, eta=p.eta or 0.5) for p in result.peaks]
    for index in range(samples):
        synthetic = result.total_fit + rng.choice(result.residual, size=len(result.residual), replace=True)
        try:
            fitted = fit_peaks(result.x, synthetic, base_specs, result.config)
            if fitted.success:
                successful.append([(p.center, p.height, p.fwhm, p.area) for p in fitted.peaks])
        except Exception:
            pass
        if progress:
            progress(index + 1, samples)
    if len(successful) < max(10, samples // 5):
        raise RuntimeError(f"Only {len(successful)}/{samples} bootstrap fits converged.")
    array = np.asarray(successful)
    for i, peak in enumerate(result.peaks):
        peak.center_ci95 = tuple(np.percentile(array[:, i, 0], [2.5, 97.5]))
        peak.height_ci95 = tuple(np.percentile(array[:, i, 1], [2.5, 97.5]))
        peak.fwhm_ci95 = tuple(np.percentile(array[:, i, 2], [2.5, 97.5]))
        peak.area_ci95 = tuple(np.percentile(array[:, i, 3], [2.5, 97.5]))
    result.bootstrap_samples = len(successful)
    return result


def compare_peak_types(x: np.ndarray, y: np.ndarray, specs: list[PeakSpec], config: FitConfig) -> list[FitResult]:
    results = []
    for peak_type in PEAK_TYPES:
        candidate = FitConfig(**asdict(config))
        candidate.peak_type = peak_type
        results.append(fit_peaks(x, y, specs, candidate))
    return sorted(results, key=lambda item: item.bic)
