from __future__ import annotations

import csv
import json
import math
import os
import re
import sys
import traceback
from datetime import datetime
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable

import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter1d
from scipy.signal import savgol_filter
from ui_widgets import CollapsibleSection, VerticalScrolledFrame, fit_window_to_screen
from csv_import import ColumnMappingRequired, automatic_mapping, inspect_csv, parse_number, template_mapping

import matplotlib as mpl
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure

import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, simpledialog, ttk


APP_NAME = "TDS Plotter"
try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    RootWindow = TkinterDnD.Tk
except ImportError:  # Source runs remain usable without optional drag-and-drop support.
    DND_FILES = None
    RootWindow = tk.Tk


APP_VERSION = "1.8.0"
APP_DATA_DIR = Path(os.getenv("LOCALAPPDATA", str(Path.home()))) / "TDS Plotter"
PREFERENCES_PATH = APP_DATA_DIR / "preferences.json"
AUTOSAVE_PATH = APP_DATA_DIR / "autosave.tdsplot"
LOG_PATH = APP_DATA_DIR / "tds_plotter.log"

mpl.rcParams.update(
    {
        "font.family": ["Arial", "DejaVu Sans"],
        "font.size": 9,
        "axes.linewidth": 0.8,
        "axes.labelsize": 10,
        "xtick.direction": "in",
        "ytick.direction": "in",
        "xtick.top": True,
        "ytick.right": True,
        "xtick.major.width": 0.8,
        "ytick.major.width": 0.8,
        "legend.frameon": False,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "savefig.facecolor": "white",
        "figure.facecolor": "white",
    }
)

PALETTE = ["#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9", "#000000", "#F0E442"]
LINESTYLES = ["-", "--", "-.", ":"]


@dataclass
class TDSData:
    path: str
    display_name: str
    metadata: list[str]
    columns: dict[str, list[float]]
    mz_columns: list[str]
    encoding: str = "utf-8"
    delimiter: str = ","
    quality_warnings: list[str] = field(default_factory=list)
    import_template: str | None = None
    import_mapping: dict | None = None
    plot_color: str | None = None

    @property
    def temperature(self) -> np.ndarray:
        return np.asarray(self.columns["Temperature1[C]"], dtype=float)

    def signal(self, mz: str) -> np.ndarray:
        return np.asarray(self.columns[mz], dtype=float)


@dataclass
class PlotSettings:
    auto_x: bool = True
    x_min: float = 0.0
    x_max: float = 1200.0
    auto_y: bool = True
    y_min: float = 1e-15
    y_max: float = 1e-8
    y_mode: str = "Log axis"
    smoothing: str = "Savitzky-Golay"
    window: int = 11
    polyorder: int = 3
    gaussian_sigma: float = 2.0
    show_raw: bool = False
    line_width: float = 1.5
    line_style: str = "-"
    color: str = "#0072B2"
    show_title: bool = True
    title_template: str = ""
    legend_template: str = ""
    legend_title: str = ""
    auto_title_font: bool = True
    title_font_size: float = 10.0
    auto_legend_font: bool = True
    legend_font_size: float = 9.0


def sample_curve_color(sample: TDSData, index: int = 0, fallback: str | None = None) -> str:
    """Return a user-selected sample color or a deterministic accessible default."""
    if sample.plot_color and mpl.colors.is_color_like(sample.plot_color):
        return sample.plot_color
    return fallback or PALETTE[index % len(PALETTE)]


def automatic_title_font_size(figure: Figure, text: str) -> float:
    """Scale long titles down while retaining a publication-readable size."""
    density = len(text) / max(float(figure.get_figwidth()), 1.0)
    return float(np.clip(12.0 - max(density - 5.5, 0.0) * 0.22, 8.0, 12.0))


def automatic_legend_font_size(figure: Figure, labels: Iterable[str]) -> float:
    labels = [str(label) for label in labels]
    density = (max((len(label) for label in labels), default=0) + 4 * max(len(labels) - 1, 0)) / max(float(figure.get_figwidth()), 1.0)
    return float(np.clip(9.5 - max(density - 3.0, 0.0) * 0.16, 7.0, 9.5))


def format_plot_text(template: str, default: str, sample: str, mz: str) -> str:
    if not template.strip():
        return default
    try:
        return template.format(sample=sample, mz=mz)
    except (KeyError, ValueError) as exc:
        raise ValueError("标题或图例模板只能使用 {sample} 和 {mz}。") from exc


def parse_tds_csv(path: str | Path, mapping: dict | None = None, templates: list[dict] | None = None) -> TDSData:
    """Parse TDS CSV while preserving missing cells as NaN and the source file unchanged."""
    source = Path(path)
    layout = inspect_csv(source)
    template_name = None
    if mapping is None:
        mapping = automatic_mapping(layout)
    if mapping is None and templates:
        mapping, template_name = template_mapping(layout, templates)
    if mapping is None:
        raise ColumnMappingRequired("无法自动识别温度列和 m/z 信号列，请手动映射。", layout)
    header_index = int(mapping.get("header_index", layout.header_index))
    headers = [cell.strip() for cell in layout.rows[header_index]]
    positions = {name: index for index, name in enumerate(headers) if name}
    temperature_source = mapping.get("temperature")
    mz_mapping = {source_name: canonical for source_name, canonical in mapping.get("mz", {}).items() if source_name in positions and canonical}
    if temperature_source not in positions or not mz_mapping:
        raise ColumnMappingRequired("列映射与当前文件不匹配，请重新选择。", layout)
    columns: dict[str, list[float]] = {"Temperature1[C]": []}
    time_source = mapping.get("time")
    if time_source in positions:
        columns["Time[s]"] = []
    for canonical in mz_mapping.values():
        columns.setdefault(canonical, [])
    counts = {name: 0 for name in columns}
    duplicate_rows = 0
    seen_rows: set[tuple] = set()
    decimal_comma = layout.delimiter != ","
    for row in layout.rows[header_index + 1:]:
        if not row or not any(str(cell).strip() for cell in row):
            continue
        def value_at(source_name):
            index = positions[source_name]
            return row[index] if index < len(row) else ""
        source_pairs = [("Temperature1[C]", temperature_source)]
        if "Time[s]" in columns:
            source_pairs.append(("Time[s]", time_source))
        source_pairs.extend((canonical, original) for original, canonical in mz_mapping.items())
        for canonical, original in source_pairs:
            try:
                value = parse_number(value_at(original), decimal_comma)
                if not np.isfinite(value):
                    counts[canonical] += 1
            except (TypeError, ValueError):
                value = float("nan"); counts[canonical] += 1
            columns[canonical].append(value)
        row_key = tuple(None if not np.isfinite(columns[name][-1]) else columns[name][-1] for name in columns)
        if row_key in seen_rows:
            duplicate_rows += 1
        else:
            seen_rows.add(row_key)
    if not columns["Temperature1[C]"]:
        raise ValueError("CSV 中没有数据行。")
    warnings = [f"{name} 有 {count} 个空值或无效值，已保留为空缺。" for name, count in counts.items() if count]
    if duplicate_rows:
        warnings.append(f"发现 {duplicate_rows} 个完全重复的数据行，已保留并请核对原始文件。")
    temperature = np.asarray(columns["Temperature1[C]"], dtype=float)
    finite_temperature = temperature[np.isfinite(temperature)]
    temperature_steps = np.diff(finite_temperature)
    repeated_temperature = int(np.count_nonzero(temperature_steps == 0))
    decreasing_temperature = int(np.count_nonzero(temperature_steps < 0))
    positive_steps = temperature_steps[temperature_steps > 0]
    if repeated_temperature:
        warnings.append(f"温度序列有 {repeated_temperature} 处相邻重复值。")
    if decreasing_temperature:
        warnings.append(f"温度序列有 {decreasing_temperature} 处回退，请确认升温程序或数据顺序。")
    if positive_steps.size:
        median_step = float(np.median(positive_steps))
        large_gaps = int(np.count_nonzero(positive_steps > 5 * median_step)) if median_step > 0 else 0
        if large_gaps:
            warnings.append(f"温度序列有 {large_gaps} 处步长超过典型步长的 5 倍，可能存在数据中断。")
    if "Time[s]" in columns:
        time_values = np.asarray(columns["Time[s]"], dtype=float)
        finite_time = time_values[np.isfinite(time_values)]
        time_rollbacks = int(np.count_nonzero(np.diff(finite_time) < 0))
        if time_rollbacks:
            warnings.append(f"时间序列有 {time_rollbacks} 处回退，请确认数据顺序。")
    if np.count_nonzero(np.isfinite(np.asarray(columns["Temperature1[C]"], dtype=float))) < 2:
        raise ValueError("温度列有效数值不足，无法绘图。")
    mz_columns = list(dict.fromkeys(mz_mapping.values()))
    return TDSData(
        path=str(source.resolve()),
        display_name=source.stem,
        metadata=[layout.delimiter.join(row) for row in layout.rows[:header_index]],
        columns=columns,
        mz_columns=mz_columns,
        encoding=layout.encoding,
        delimiter={",": "逗号", ";": "分号", "\t": "制表符"}.get(layout.delimiter, layout.delimiter),
        quality_warnings=warnings,
        import_template=template_name,
        import_mapping=mapping,
    )


def normalized_window(window: int, length: int, polyorder: int = 0) -> int:
    candidate = max(int(window), polyorder + 2, 3)
    if candidate % 2 == 0:
        candidate += 1
    maximum = length if length % 2 else length - 1
    return max(1, min(candidate, maximum))


def smooth_signal(y: np.ndarray, settings: PlotSettings) -> np.ndarray:
    values = np.asarray(y, dtype=float)
    if settings.smoothing == "None" or len(values) < 3:
        return values.copy()
    result = np.full_like(values, np.nan)
    finite = np.isfinite(values)
    boundaries = np.diff(np.r_[False, finite, False].astype(int))
    starts, ends = np.where(boundaries == 1)[0], np.where(boundaries == -1)[0]
    for start, end in zip(starts, ends):
        segment = values[start:end]
        result[start:end] = _smooth_finite_segment(segment, settings)
    return result


def _smooth_finite_segment(y: np.ndarray, settings: PlotSettings) -> np.ndarray:
    if len(y) < 3:
        return y.copy()
    if settings.smoothing == "Savitzky-Golay":
        window = normalized_window(settings.window, len(y), settings.polyorder)
        if window <= settings.polyorder:
            return y.copy()
        return savgol_filter(y, window_length=window, polyorder=settings.polyorder, mode="interp")
    if settings.smoothing == "Moving average":
        window = normalized_window(settings.window, len(y))
        kernel = np.ones(window, dtype=float) / window
        padded = np.pad(y, (window // 2, window // 2), mode="edge")
        return np.convolve(padded, kernel, mode="valid")
    if settings.smoothing == "Gaussian":
        return gaussian_filter1d(y, sigma=max(settings.gaussian_sigma, 0.1), mode="nearest")
    raise ValueError(f"未知平滑方法：{settings.smoothing}")


def positive_floor(settings: PlotSettings, series: Iterable[np.ndarray]) -> float:
    if not settings.auto_y and settings.y_min > 0:
        return settings.y_min / 10.0
    positives = np.concatenate([values[np.isfinite(values) & (values > 0)] for values in series])
    if positives.size == 0:
        return 1e-16
    decade = 10.0 ** math.floor(math.log10(float(np.min(positives))))
    return decade / 10.0


def apply_y_policy(y: np.ndarray, settings: PlotSettings, floor: float) -> tuple[np.ndarray, int]:
    result = np.asarray(y, dtype=float).copy()
    mask = ~np.isfinite(result) | (result <= 0)
    count = int(np.count_nonzero(mask))
    if settings.y_mode in {"Log axis", "Log10 transformed"}:
        result[mask] = floor
    if settings.y_mode == "Log10 transformed":
        result = np.log10(result)
    return result, count


def configure_axis(ax, settings: PlotSettings, title: str | None = None) -> None:
    ax.set_xlabel("Temperature (°C)")
    ax.set_ylabel("log₁₀[Ion current (A)]" if settings.y_mode == "Log10 transformed" else "Ion current (A)")
    if not settings.auto_x:
        ax.set_xlim(settings.x_min, settings.x_max)
    if settings.y_mode == "Log axis":
        ax.set_yscale("log")
    else:
        ax.set_yscale("linear")
    if not settings.auto_y:
        if settings.y_mode == "Log10 transformed":
            if settings.y_min <= 0 or settings.y_max <= 0:
                raise ValueError("Log10 transformed 模式的纵轴范围必须用正的原始电流值填写。")
            ax.set_ylim(np.log10(settings.y_min), np.log10(settings.y_max))
        else:
            ax.set_ylim(settings.y_min, settings.y_max)
    if settings.show_title and title:
        size = automatic_title_font_size(ax.figure, title) if settings.auto_title_font else settings.title_font_size
        ax.set_title(title, fontsize=size, pad=8)
    ax.tick_params(which="both", direction="in", top=True, right=True)
    x_formatter = mpl.ticker.ScalarFormatter(useOffset=False)
    x_formatter.set_scientific(False)
    ax.xaxis.set_major_formatter(x_formatter)
    for spine in ax.spines.values():
        spine.set_color("black")
        spine.set_linewidth(0.8)


def apply_data_limits(
    ax,
    settings: PlotSettings,
    x_series: list[np.ndarray],
    source_y_series: list[np.ndarray],
    plotted_y_series: list[np.ndarray],
) -> None:
    """Fit axes tightly to valid observations, excluding log replacement values."""
    finite_x = [np.asarray(x)[np.isfinite(x)] for x in x_series]
    finite_x = [x for x in finite_x if x.size]
    if settings.auto_x and finite_x:
        all_x = np.concatenate(finite_x)
        x_low, x_high = float(np.min(all_x)), float(np.max(all_x))
        if x_low == x_high:
            x_low, x_high = x_low - 0.5, x_high + 0.5
        ax.set_xlim(x_low, x_high)

    valid_plotted: list[np.ndarray] = []
    for x, source, plotted in zip(x_series, source_y_series, plotted_y_series):
        x = np.asarray(x, dtype=float)
        source = np.asarray(source, dtype=float)
        plotted = np.asarray(plotted, dtype=float)
        mask = np.isfinite(x) & np.isfinite(source) & np.isfinite(plotted)
        if settings.y_mode in {"Log axis", "Log10 transformed"}:
            # Replacement values preserve curve continuity but must not expand
            # the visible range and compress valid experimental observations.
            mask &= source > 0
        x_low, x_high = ax.get_xlim()
        mask &= (x >= x_low) & (x <= x_high)
        if np.any(mask):
            valid_plotted.append(plotted[mask])

    if not settings.auto_y or not valid_plotted:
        return
    values = np.concatenate(valid_plotted)
    y_low, y_high = float(np.min(values)), float(np.max(values))
    if settings.y_mode == "Log axis":
        log_low, log_high = math.log10(y_low), math.log10(y_high)
        span = max(log_high - log_low, 0.2)
        padding = span * 0.04
        ax.set_ylim(10 ** (log_low - padding), 10 ** (log_high + padding))
    else:
        span = y_high - y_low
        padding = span * 0.04 if span > 0 else max(abs(y_low) * 0.04, 0.5)
        ax.set_ylim(y_low - padding, y_high + padding)


def export_figure(figure: Figure, path: Path, provenance: dict) -> None:
    """Export an opaque publication figure and a machine-readable processing record."""
    path.parent.mkdir(parents=True, exist_ok=True)
    suffix = path.suffix.lower()
    if suffix not in {".png", ".pdf", ".svg"}:
        raise ValueError("仅支持 PNG、PDF 和 SVG。")
    if suffix == ".png":
        # PNG stores resolution as integer pixels/metre. 600.02 avoids rounding
        # the metadata just below the requested 600 dpi.
        figure.savefig(path, dpi=600.02, facecolor="white", transparent=False)
        with Image.open(path) as image:
            rgb = Image.new("RGB", image.size, "white")
            if image.mode == "RGBA":
                rgb.paste(image, mask=image.getchannel("A"))
            else:
                rgb.paste(image.convert("RGB"))
            rgb.save(path, format="PNG", dpi=(600.02, 600.02), optimize=True)
    else:
        figure.savefig(path, dpi=300, facecolor="white", transparent=False)
    manifest = path.with_suffix(path.suffix + ".json")
    manifest.write_text(json.dumps(provenance, ensure_ascii=False, indent=2), encoding="utf-8")


class FigurePage(ttk.Frame):
    def __init__(self, master, figure: Figure, key: str, provenance: dict):
        super().__init__(master)
        self.figure = figure
        self.key = key
        self.provenance = provenance
        self.canvas = FigureCanvasTkAgg(figure, master=self)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill="both", expand=True)
        toolbar = NavigationToolbar2Tk(self.canvas, self, pack_toolbar=False)
        toolbar.update()
        toolbar.pack(fill="x")


class ColumnMappingDialog(tk.Toplevel):
    def __init__(self, parent, layout, templates):
        super().__init__(parent)
        self.title("手动列映射")
        fit_window_to_screen(self, 760, 760, 680, 560)
        self.transient(parent); self.grab_set()
        self.layout = layout; self.templates = templates; self.result = None; self.saved_template = None
        self.header_row_var = tk.StringVar(value=str(layout.header_index + 1))
        self.temperature_var, self.time_var = tk.StringVar(), tk.StringVar(value="（不使用）")
        self.template_var = tk.StringVar()
        self.template_name_var = tk.StringVar()
        top = ttk.Frame(self, padding=12); top.pack(fill="both", expand=True)
        ttk.Label(top, text=f"文件：{Path(layout.path).name}", font=("Microsoft YaHei UI", 11, "bold")).pack(anchor="w")
        ttk.Label(top, text=f"检测：{layout.encoding}；分隔符：{repr(layout.delimiter)}。请选择温度列，并为信号列指定 m/z。", foreground="#526A7C").pack(anchor="w", pady=(3, 10))
        row = ttk.Frame(top); row.pack(fill="x")
        ttk.Label(row, text="表头所在行").pack(side="left")
        ttk.Spinbox(row, from_=1, to=max(1, len(layout.rows)), textvariable=self.header_row_var, width=7).pack(side="left", padx=5)
        ttk.Button(row, text="读取该行", command=self._reload_headers).pack(side="left")
        ttk.Label(row, text="已保存模板").pack(side="left", padx=(18, 4))
        self.template_combo = ttk.Combobox(row, textvariable=self.template_var, values=[item.get("name", "") for item in templates], state="readonly", width=18)
        self.template_combo.pack(side="left"); ttk.Button(row, text="应用", command=self._apply_template).pack(side="left", padx=4)
        mapping = ttk.LabelFrame(top, text="必需列"); mapping.pack(fill="x", pady=10)
        ttk.Label(mapping, text="温度列").grid(row=0, column=0, padx=8, pady=5, sticky="w")
        self.temperature_combo = ttk.Combobox(mapping, textvariable=self.temperature_var, state="readonly")
        self.temperature_combo.grid(row=0, column=1, padx=8, pady=5, sticky="ew")
        ttk.Label(mapping, text="时间列（可选）").grid(row=1, column=0, padx=8, pady=5, sticky="w")
        self.time_combo = ttk.Combobox(mapping, textvariable=self.time_var, state="readonly")
        self.time_combo.grid(row=1, column=1, padx=8, pady=5, sticky="ew"); mapping.columnconfigure(1, weight=1)
        preview_frame = ttk.LabelFrame(top, text="数据预览（表头及前 10 行）"); preview_frame.pack(fill="x", pady=(0, 10))
        self.preview_text = tk.Text(preview_frame, height=7, wrap="none", font=("Consolas", 9), background="#FFFFFF")
        self.preview_text.pack(fill="x", padx=6, pady=6)
        signal = ttk.LabelFrame(top, text="m/z 信号列"); signal.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(signal, columns=("source", "mz"), show="headings", selectmode="extended")
        self.tree.heading("source", text="原始列名"); self.tree.heading("mz", text="映射为")
        self.tree.column("source", width=330); self.tree.column("mz", width=120, anchor="center")
        self.tree.pack(fill="both", expand=True, padx=6, pady=6)
        self.tree.bind("<Double-1>", lambda _e: self.assign_mz())
        signal_buttons = ttk.Frame(signal); signal_buttons.pack(fill="x", padx=6, pady=(0, 6))
        ttk.Button(signal_buttons, text="为所选列指定 m/z", command=self.assign_mz).pack(side="left")
        ttk.Button(signal_buttons, text="清除映射", command=self.clear_mz).pack(side="left", padx=5)
        save_row = ttk.Frame(top); save_row.pack(fill="x", pady=8)
        ttk.Label(save_row, text="保存为格式模板（可选）").pack(side="left")
        ttk.Entry(save_row, textvariable=self.template_name_var).pack(side="left", fill="x", expand=True, padx=6)
        buttons = ttk.Frame(top); buttons.pack(fill="x")
        ttk.Button(buttons, text="取消", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(buttons, text="确认导入", command=self.accept, style="Primary.TButton").pack(side="right")
        self._reload_headers()

    def _reload_headers(self):
        try:
            index = int(self.header_row_var.get()) - 1
            if not 0 <= index < len(self.layout.rows):
                raise ValueError
        except ValueError:
            messagebox.showerror("表头行无效", "请输入有效的表头行号。", parent=self); return
        headers = [cell.strip() for cell in self.layout.rows[index] if cell.strip()]
        preview_rows = self.layout.rows[index:index + 11]
        preview_lines = [" | ".join((str(cell).strip()[:24] or "(空)") for cell in row) for row in preview_rows]
        self.preview_text.configure(state="normal")
        self.preview_text.delete("1.0", "end")
        self.preview_text.insert("1.0", "\n".join(preview_lines))
        self.preview_text.configure(state="disabled")
        self.temperature_combo.configure(values=headers)
        self.time_combo.configure(values=["（不使用）", *headers])
        self.tree.delete(*self.tree.get_children())
        from csv_import import canonical_mz
        for position, header in enumerate(headers):
            self.tree.insert("", "end", iid=str(position), values=(header, canonical_mz(header) or ""))
        auto_temp = next((header for header in headers if re.search(r"temperature|temp|温度", header, re.I)), "")
        self.temperature_var.set(auto_temp); self.time_var.set("（不使用）")

    def assign_mz(self):
        selected = self.tree.selection()
        if not selected:
            return
        value = simpledialog.askstring("指定 m/z", "请输入质量数，例如 18：", parent=self)
        try:
            number = float(value)
            label = f"m/z {int(number)}" if number.is_integer() else f"m/z {number:g}"
        except (TypeError, ValueError):
            if value is not None:
                messagebox.showerror("m/z 无效", "请输入正的数字质量数。", parent=self)
            return
        if number <= 0:
            messagebox.showerror("m/z 无效", "请输入正的数字质量数。", parent=self); return
        for item in selected:
            values = list(self.tree.item(item, "values")); values[1] = label; self.tree.item(item, values=values)

    def clear_mz(self):
        for item in self.tree.selection():
            values = list(self.tree.item(item, "values")); values[1] = ""; self.tree.item(item, values=values)

    def _apply_template(self):
        template = next((item for item in self.templates if item.get("name") == self.template_var.get()), None)
        if not template:
            return
        sources = {self.tree.item(item, "values")[0]: item for item in self.tree.get_children()}
        if template.get("temperature") in sources:
            self.temperature_var.set(template["temperature"])
        self.time_var.set(template.get("time") if template.get("time") in sources else "（不使用）")
        for source, mz in template.get("mz", {}).items():
            if source in sources:
                values = list(self.tree.item(sources[source], "values")); values[1] = mz; self.tree.item(sources[source], values=values)

    def accept(self):
        temperature = self.temperature_var.get()
        mappings = {}
        for item in self.tree.get_children():
            source, mz = self.tree.item(item, "values")
            if mz:
                mappings[source] = mz
        if not temperature or not mappings:
            messagebox.showerror("映射不完整", "必须选择温度列，并至少映射一个 m/z 信号列。", parent=self); return
        self.result = {"header_index": int(self.header_row_var.get()) - 1, "temperature": temperature,
                       "time": None if self.time_var.get() == "（不使用）" else self.time_var.get(), "mz": mappings}
        name = self.template_name_var.get().strip()
        if name:
            self.saved_template = {"name": name, "temperature": temperature, "time": self.result["time"], "mz": mappings}
        self.destroy()


class TDSPlotterApp(RootWindow):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"{APP_NAME} {APP_VERSION}")
        fit_window_to_screen(self, 1420, 860, 900, 560)
        self.samples: list[TDSData] = []
        self.settings = PlotSettings()
        self.pages: list[FigurePage] = []
        self.fit_sessions: dict[str, dict] = {}
        self.current_project: str | None = None
        self.preferences = self._load_preferences()
        self._previous_clean_exit = bool(self.preferences.get("clean_exit", True))
        self.preferences["clean_exit"] = False
        self._save_preferences()
        self._closing_normally = False
        self._build_style()
        self._build_menu()
        self._build_ui()
        self._sync_controls_from_settings()
        self._bind_change_tracking()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self._enable_drag_and_drop()
        self.after(400, self._offer_crash_recovery)
        self.after(30000, self._autosave_tick)

    def _load_preferences(self) -> dict:
        try:
            return json.loads(PREFERENCES_PATH.read_text(encoding="utf-8"))
        except Exception:
            return {"recent_projects": [], "clean_exit": True}

    def _save_preferences(self) -> None:
        APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
        PREFERENCES_PATH.write_text(json.dumps(self.preferences, ensure_ascii=False, indent=2), encoding="utf-8")

    def _project_payload(self) -> dict:
        try:
            settings = self._read_settings()
        except Exception:
            settings = self.settings
        return {
            "format_version": 1,
            "samples": [{"path": s.path, "display_name": s.display_name, "import_mapping": s.import_mapping,
                         "plot_color": s.plot_color} for s in self.samples],
            "settings": asdict(settings), "mode": self.mode_var.get(),
            "selected_mz": self.selected_mz(), "fit_sessions": self.fit_sessions,
        }

    def _autosave_tick(self) -> None:
        if not self._closing_normally and self.samples:
            try:
                APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
                temporary = AUTOSAVE_PATH.with_suffix(".tmp")
                temporary.write_text(json.dumps(self._project_payload(), ensure_ascii=False, indent=2), encoding="utf-8")
                temporary.replace(AUTOSAVE_PATH)
            except Exception as exc:
                self._write_log("自动保存失败", exc)
        if not self._closing_normally:
            self.after(30000, self._autosave_tick)

    def _offer_crash_recovery(self) -> None:
        if not self._previous_clean_exit and AUTOSAVE_PATH.exists():
            if messagebox.askyesno("恢复上次工作", "检测到上次程序可能异常关闭。是否恢复自动保存的工作？", parent=self):
                try:
                    self._apply_project_payload(json.loads(AUTOSAVE_PATH.read_text(encoding="utf-8")))
                    self.status_var.set("已恢复上次自动保存的工作。请检查后另存项目。")
                except Exception as exc:
                    self._write_log("恢复失败", exc)
                    messagebox.showerror("恢复失败", "恢复文件无法读取，详细信息已写入日志。", parent=self)

    def _on_close(self) -> None:
        if self.samples:
            self._autosave_tick()
        self._closing_normally = True
        self.preferences["clean_exit"] = True
        self._save_preferences()
        self.destroy()

    def _write_log(self, context: str, exc: BaseException) -> None:
        APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
        with LOG_PATH.open("a", encoding="utf-8") as handle:
            handle.write(f"\n[{context}] {type(exc).__name__}: {exc}\n")
            handle.write("".join(traceback.format_exception(type(exc), exc, exc.__traceback__)))

    def report_callback_exception(self, exc_type, exc_value, exc_traceback) -> None:
        self._write_log("界面操作异常", exc_value)
        messagebox.showerror("操作未完成", f"发生了意外问题：{exc_value}\n\n诊断日志：{LOG_PATH}", parent=self)

    def _enable_drag_and_drop(self) -> None:
        if DND_FILES is None:
            return
        self.drop_target_register(DND_FILES)
        self.dnd_bind("<<Drop>>", self._on_drop)

    def _on_drop(self, event) -> None:
        paths = list(self.tk.splitlist(event.data))
        csv_paths = [path for path in paths if Path(path).suffix.lower() == ".csv"]
        if csv_paths:
            self.import_files(csv_paths)
        else:
            messagebox.showinfo("无法导入", "请拖入一个或多个 CSV 文件。", parent=self)

    def _build_style(self) -> None:
        style = ttk.Style(self)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        self.configure(background="#EDF3F8")
        style.configure(".", font=("Microsoft YaHei UI", 9), background="#EDF3F8", foreground="#243447")
        style.configure("TFrame", background="#EDF3F8")
        style.configure("Card.TFrame", background="#FFFFFF")
        style.configure("Title.TLabel", font=("Microsoft YaHei UI", 16, "bold"), foreground="#163A5F", background="#EDF3F8")
        style.configure("Subtitle.TLabel", font=("Microsoft YaHei UI", 10), foreground="#587187", background="#EDF3F8")
        style.configure("CardHeader.TButton", anchor="w", font=("Microsoft YaHei UI", 10, "bold"), padding=(9, 7), background="#DCEAF5", foreground="#214E73", borderwidth=0)
        style.map("CardHeader.TButton", background=[("active", "#C9E0F1")])
        style.configure("Primary.TButton", font=("Microsoft YaHei UI", 10, "bold"), padding=(9, 7), foreground="white", background="#2B6F9F")
        style.map("Primary.TButton", background=[("active", "#1F5C87")])
        style.configure("Welcome.TFrame", background="#F7FAFD")
        style.configure("WelcomeTitle.TLabel", font=("Microsoft YaHei UI", 22, "bold"), foreground="#153B5B", background="#F7FAFD")
        style.configure("WelcomeText.TLabel", font=("Microsoft YaHei UI", 10), foreground="#60798E", background="#F7FAFD")

    def _build_menu(self) -> None:
        menu = tk.Menu(self)
        file_menu = tk.Menu(menu, tearoff=False)
        file_menu.add_command(label="导入 CSV…", command=self.import_files, accelerator="Ctrl+O")
        file_menu.add_separator()
        file_menu.add_command(label="保存项目…", command=self.save_project, accelerator="Ctrl+S")
        file_menu.add_command(label="打开项目…", command=self.open_project)
        file_menu.add_command(label="返回欢迎页", command=self.show_welcome)
        file_menu.add_separator()
        file_menu.add_command(label="退出", command=self.destroy)
        menu.add_cascade(label="文件", menu=file_menu)
        analysis_menu = tk.Menu(menu, tearoff=False)
        analysis_menu.add_command(label="分峰拟合…", command=self.open_peak_fitting)
        menu.add_cascade(label="分析", menu=analysis_menu)
        help_menu = tk.Menu(menu, tearoff=False)
        help_menu.add_command(label="关于", command=lambda: messagebox.showinfo("关于", f"{APP_NAME} {APP_VERSION}\nTDS 学术绘图工具"))
        menu.add_cascade(label="帮助", menu=help_menu)
        self.config(menu=menu)
        self.bind("<Control-o>", lambda _e: self.import_files())
        self.bind("<Control-s>", lambda _e: self.save_project())

    def _build_ui(self) -> None:
        root = ttk.Panedwindow(self, orient="horizontal")
        root.pack(fill="both", expand=True, padx=8, pady=8)
        control_scroller = VerticalScrolledFrame(root, width=365)
        controls = control_scroller.content
        preview = ttk.Frame(root)
        root.add(control_scroller, weight=0)
        root.add(preview, weight=1)

        ttk.Label(controls, text=APP_NAME, style="Title.TLabel").pack(anchor="w", pady=(0, 7))

        files_card = CollapsibleSection(controls, "数据文件", expanded=True); files_card.pack(fill="x", pady=4)
        files = files_card.content
        button_row = ttk.Frame(files)
        button_row.pack(fill="x", padx=6, pady=6)
        ttk.Button(button_row, text="导入 CSV", command=self.import_files).pack(side="left", expand=True, fill="x")
        ttk.Button(button_row, text="移除", command=self.remove_samples).pack(side="left", expand=True, fill="x", padx=(5, 0))
        self.sample_tree = ttk.Treeview(files, columns=("name", "color"), show="headings", height=5, selectmode="extended")
        self.sample_tree.heading("name", text="显示名称（双击修改）")
        self.sample_tree.heading("color", text="曲线颜色")
        self.sample_tree.column("name", width=210)
        self.sample_tree.column("color", width=85, anchor="center")
        self.sample_tree.pack(fill="x", padx=6, pady=(0, 6))
        self.sample_tree.bind("<Double-1>", self.rename_sample)
        self.sample_tree.bind("<<TreeviewSelect>>", lambda _e: self.refresh_mz_list())
        color_row = ttk.Frame(files); color_row.pack(fill="x", padx=6, pady=(0, 6))
        ttk.Button(color_row, text="设置所选样品颜色", command=self.choose_sample_color).pack(side="left", expand=True, fill="x")
        ttk.Button(color_row, text="恢复自动配色", command=self.reset_sample_colors).pack(side="left", expand=True, fill="x", padx=(5, 0))

        mode_card = CollapsibleSection(controls, "绘图模式", expanded=True); mode_card.pack(fill="x", pady=4)
        mode_box = mode_card.content
        self.mode_var = tk.StringVar(value="single")
        ttk.Radiobutton(mode_box, text="单样品：每个 m/z 分页", variable=self.mode_var, value="single", command=self.on_mode_change).pack(anchor="w", padx=6, pady=2)
        ttk.Radiobutton(mode_box, text="多样品：固定 m/z 横向比较", variable=self.mode_var, value="compare", command=self.on_mode_change).pack(anchor="w", padx=6, pady=2)
        self.mz_list = tk.Listbox(mode_box, selectmode="extended", exportselection=False, height=5)
        self.mz_list.pack(fill="x", padx=6, pady=6)

        axes_card = CollapsibleSection(controls, "坐标与平滑", expanded=True); axes_card.pack(fill="x", pady=4)
        axes = axes_card.content
        grid = ttk.Frame(axes)
        grid.pack(fill="x", padx=6, pady=5)
        self.xmin_var, self.xmax_var = tk.StringVar(), tk.StringVar()
        self.ymin_var, self.ymax_var = tk.StringVar(), tk.StringVar()
        self.ymode_var = tk.StringVar()
        self.smoothing_var = tk.StringVar()
        self.window_var, self.poly_var, self.sigma_var = tk.StringVar(), tk.StringVar(), tk.StringVar()
        self.auto_x_var, self.auto_y_var, self.show_raw_var = tk.BooleanVar(), tk.BooleanVar(), tk.BooleanVar()
        rows = [
            ("X min (°C)", self.xmin_var, "X max (°C)", self.xmax_var),
            ("Y min (A)", self.ymin_var, "Y max (A)", self.ymax_var),
        ]
        for r, (l1, v1, l2, v2) in enumerate(rows):
            ttk.Label(grid, text=l1).grid(row=r, column=0, sticky="w", pady=2)
            ttk.Entry(grid, textvariable=v1, width=10).grid(row=r, column=1, padx=(3, 8))
            ttk.Label(grid, text=l2).grid(row=r, column=2, sticky="w")
            ttk.Entry(grid, textvariable=v2, width=10).grid(row=r, column=3, padx=(3, 0))
        ttk.Checkbutton(grid, text="横轴自动范围", variable=self.auto_x_var).grid(row=2, column=0, columnspan=2, sticky="w", pady=3)
        ttk.Checkbutton(grid, text="纵轴自动范围", variable=self.auto_y_var, command=self._toggle_y_entries).grid(row=2, column=2, columnspan=2, sticky="w", pady=3)
        ttk.Label(grid, text="纵轴模式").grid(row=3, column=0, sticky="w")
        ttk.Combobox(grid, textvariable=self.ymode_var, values=["Log axis", "Linear", "Log10 transformed"], state="readonly", width=19).grid(row=3, column=1, columnspan=3, sticky="ew", pady=2)
        ttk.Label(grid, text="平滑方法").grid(row=4, column=0, sticky="w")
        ttk.Combobox(grid, textvariable=self.smoothing_var, values=["Savitzky-Golay", "Moving average", "Gaussian", "None"], state="readonly", width=19).grid(row=4, column=1, columnspan=3, sticky="ew", pady=2)
        ttk.Label(grid, text="窗口").grid(row=5, column=0, sticky="w")
        ttk.Entry(grid, textvariable=self.window_var, width=10).grid(row=5, column=1, padx=(3, 8))
        ttk.Label(grid, text="阶数").grid(row=5, column=2, sticky="w")
        ttk.Entry(grid, textvariable=self.poly_var, width=10).grid(row=5, column=3, padx=(3, 0))
        ttk.Label(grid, text="Gaussian σ").grid(row=6, column=0, sticky="w")
        ttk.Entry(grid, textvariable=self.sigma_var, width=10).grid(row=6, column=1, padx=(3, 8))
        ttk.Checkbutton(grid, text="同时显示原始曲线", variable=self.show_raw_var).grid(row=6, column=2, columnspan=2, sticky="w")

        style_card = CollapsibleSection(controls, "曲线样式", expanded=False); style_card.pack(fill="x", pady=4)
        style_box = style_card.content
        style_row = ttk.Frame(style_box)
        style_row.pack(fill="x", padx=6, pady=6)
        self.width_var, self.linestyle_var = tk.StringVar(), tk.StringVar()
        ttk.Label(style_row, text="线宽").pack(side="left")
        ttk.Entry(style_row, textvariable=self.width_var, width=6).pack(side="left", padx=4)
        ttk.Label(style_row, text="线型").pack(side="left", padx=(8, 0))
        ttk.Combobox(style_row, textvariable=self.linestyle_var, values=LINESTYLES, state="readonly", width=5).pack(side="left", padx=4)
        self.color_button = ttk.Button(style_row, text="选择颜色", command=self.choose_color)
        self.color_button.pack(side="right")

        text_card = CollapsibleSection(controls, "标题与图例", expanded=False); text_card.pack(fill="x", pady=4)
        text_box = text_card.content
        text_grid = ttk.Frame(text_box)
        text_grid.pack(fill="x", padx=6, pady=5)
        self.show_title_var = tk.BooleanVar()
        self.title_template_var, self.legend_template_var = tk.StringVar(), tk.StringVar()
        self.auto_title_font_var, self.auto_legend_font_var = tk.BooleanVar(), tk.BooleanVar()
        self.title_font_var, self.legend_font_var = tk.StringVar(), tk.StringVar()
        ttk.Checkbutton(text_grid, text="显示标题", variable=self.show_title_var).grid(row=0, column=0, columnspan=2, sticky="w")
        ttk.Label(text_grid, text="标题").grid(row=1, column=0, sticky="w", pady=2)
        ttk.Entry(text_grid, textvariable=self.title_template_var).grid(row=1, column=1, sticky="ew", padx=(5, 0))
        ttk.Label(text_grid, text="曲线名称").grid(row=2, column=0, sticky="w", pady=2)
        ttk.Entry(text_grid, textvariable=self.legend_template_var).grid(row=2, column=1, sticky="ew", padx=(5, 0))
        self.legend_title_var = tk.StringVar()
        ttk.Label(text_grid, text="图例标题").grid(row=3, column=0, sticky="w", pady=2)
        ttk.Entry(text_grid, textvariable=self.legend_title_var).grid(row=3, column=1, sticky="ew", padx=(5, 0))
        ttk.Checkbutton(text_grid, text="标题字号自动", variable=self.auto_title_font_var).grid(row=4, column=0, sticky="w")
        title_font_entry = ttk.Entry(text_grid, textvariable=self.title_font_var, width=7)
        title_font_entry.grid(row=4, column=1, sticky="w", padx=5)
        ttk.Checkbutton(text_grid, text="图例字号自动", variable=self.auto_legend_font_var).grid(row=5, column=0, sticky="w")
        legend_font_entry = ttk.Entry(text_grid, textvariable=self.legend_font_var, width=7)
        legend_font_entry.grid(row=5, column=1, sticky="w", padx=5)
        for entry, variable in ((title_font_entry, self.auto_title_font_var), (legend_font_entry, self.auto_legend_font_var)):
            entry.bind("<KeyRelease>", lambda _e, v=variable: v.set(False))
            entry.bind("<<Paste>>", lambda _e, v=variable: self.after_idle(v.set, False))
        ttk.Label(text_grid, text="多样品曲线名用分号分隔；手动输入字号会关闭自动", foreground="#555555", wraplength=325).grid(row=6, column=0, columnspan=2, sticky="w", pady=(3, 0))
        text_grid.columnconfigure(1, weight=1)

        actions = ttk.Frame(controls)
        actions.pack(fill="x", pady=7)
        ttk.Button(actions, text="生成 / 刷新预览", command=self.generate_plots, style="Primary.TButton").pack(fill="x", pady=2)
        ttk.Button(actions, text="打开分峰拟合工作区", command=self.open_peak_fitting).pack(fill="x", pady=2)
        ttk.Button(actions, text="导出完整分析报告", command=self.export_analysis_report).pack(fill="x", pady=2)
        export_row = ttk.Frame(actions)
        export_row.pack(fill="x", pady=2)
        ttk.Button(export_row, text="导出当前图", command=self.export_current).pack(side="left", fill="x", expand=True)
        ttk.Button(export_row, text="导出全部分页", command=self.export_all).pack(side="left", fill="x", expand=True, padx=(5, 0))

        self.status_var = tk.StringVar(value="请导入 TDS CSV 文件。")
        self.preview_state_var = tk.StringVar(value="● 尚未生成预览")
        self.preview_state_label = ttk.Label(controls, textvariable=self.preview_state_var, foreground="#A46218")
        self.preview_state_label.pack(fill="x", pady=(4, 0))
        ttk.Label(controls, textvariable=self.status_var, wraplength=330, foreground="#444444").pack(fill="x", pady=4)

        self.plot_notebook = ttk.Notebook(preview)
        self.plot_notebook.pack(fill="both", expand=True)
        welcome = ttk.Frame(self.plot_notebook, style="Welcome.TFrame", padding=35)
        self.welcome_page = welcome
        ttk.Label(welcome, text="TDS Plotter", style="WelcomeTitle.TLabel").pack(anchor="center", pady=(50, 5))
        ttk.Label(welcome, text="热脱附质谱绘图与分峰分析", style="WelcomeText.TLabel").pack(anchor="center", pady=(0, 25))
        welcome_buttons = ttk.Frame(welcome, style="Welcome.TFrame")
        welcome_buttons.pack()
        ttk.Button(welcome_buttons, text="打开 CSV", command=self.import_files, style="Primary.TButton", width=19).grid(row=0, column=0, padx=6, pady=6)
        ttk.Button(welcome_buttons, text="打开项目", command=self.open_project, width=19).grid(row=0, column=1, padx=6, pady=6)
        ttk.Button(welcome_buttons, text="载入示例数据", command=self.load_demo_data, width=19).grid(row=1, column=0, padx=6, pady=6)
        ttk.Button(welcome_buttons, text="快速使用说明", command=self.show_quick_help, width=19).grid(row=1, column=1, padx=6, pady=6)
        ttk.Label(welcome, text="最近项目", style="WelcomeText.TLabel").pack(anchor="center", pady=(25, 5))
        self.recent_list = tk.Listbox(welcome, height=5, width=72, relief="flat", bg="#FFFFFF", fg="#2A4155", selectbackground="#BBD8EC")
        self.recent_list.pack(anchor="center")
        self.recent_list.bind("<Double-1>", lambda _e: self.open_recent_project())
        recent_buttons = ttk.Frame(welcome, style="Welcome.TFrame"); recent_buttons.pack(pady=5)
        ttk.Button(recent_buttons, text="打开所选", command=self.open_recent_project).pack(side="left", padx=4)
        ttk.Button(recent_buttons, text="移除记录", command=self.remove_recent_project).pack(side="left", padx=4)
        self._refresh_recent_list()
        self.plot_notebook.add(welcome, text="欢迎")

    def _sync_controls_from_settings(self) -> None:
        s = self.settings
        self.auto_x_var.set(s.auto_x)
        self.xmin_var.set(f"{s.x_min:.2f}")
        self.xmax_var.set(f"{s.x_max:.2f}")
        self.auto_y_var.set(s.auto_y)
        self.ymin_var.set(f"{s.y_min:g}")
        self.ymax_var.set(f"{s.y_max:g}")
        self.ymode_var.set(s.y_mode)
        self.smoothing_var.set(s.smoothing)
        self.window_var.set(str(s.window))
        self.poly_var.set(str(s.polyorder))
        self.sigma_var.set(f"{s.gaussian_sigma:g}")
        self.show_raw_var.set(s.show_raw)
        self.width_var.set(f"{s.line_width:g}")
        self.linestyle_var.set(s.line_style)
        self.show_title_var.set(s.show_title)
        self.title_template_var.set(s.title_template)
        self.legend_template_var.set(s.legend_template)
        self.legend_title_var.set(s.legend_title)
        self.auto_title_font_var.set(s.auto_title_font)
        self.title_font_var.set(f"{s.title_font_size:g}")
        self.auto_legend_font_var.set(s.auto_legend_font)
        self.legend_font_var.set(f"{s.legend_font_size:g}")
        self._toggle_y_entries()

    def _read_settings(self) -> PlotSettings:
        s = PlotSettings(
            auto_x=self.auto_x_var.get(), x_min=float(self.xmin_var.get()), x_max=float(self.xmax_var.get()),
            auto_y=self.auto_y_var.get(), y_min=float(self.ymin_var.get()), y_max=float(self.ymax_var.get()),
            y_mode=self.ymode_var.get(), smoothing=self.smoothing_var.get(),
            window=int(self.window_var.get()), polyorder=int(self.poly_var.get()),
            gaussian_sigma=float(self.sigma_var.get()), show_raw=self.show_raw_var.get(),
            line_width=float(self.width_var.get()), line_style=self.linestyle_var.get(), color=self.settings.color,
            show_title=self.show_title_var.get(), title_template=self.title_template_var.get().strip(),
            legend_template=self.legend_template_var.get().strip(), auto_title_font=self.auto_title_font_var.get(),
            legend_title=self.legend_title_var.get().strip(),
            title_font_size=float(self.title_font_var.get()), auto_legend_font=self.auto_legend_font_var.get(),
            legend_font_size=float(self.legend_font_var.get()),
        )
        if not s.auto_x and s.x_min >= s.x_max:
            raise ValueError("X min 必须小于 X max。")
        if not s.auto_y and (s.y_min <= 0 and s.y_mode != "Linear"):
            raise ValueError("对数模式下 Y min 必须大于 0。")
        if not s.auto_y and s.y_min >= s.y_max:
            raise ValueError("Y min 必须小于 Y max。")
        if s.window < 3 or s.window % 2 == 0:
            raise ValueError("平滑窗口必须是大于等于 3 的奇数。")
        if s.polyorder < 1 or s.polyorder >= s.window:
            raise ValueError("Savitzky-Golay 阶数必须小于窗口。")
        if not (6 <= s.title_font_size <= 36 and 6 <= s.legend_font_size <= 36):
            raise ValueError("标题和图例字号应在 6–36 pt 之间。")
        format_plot_text(s.title_template, "", "sample", "m/z 18")
        format_plot_text(s.legend_template, "", "sample", "m/z 18")
        return s

    def _toggle_y_entries(self) -> None:
        # Values remain editable so users can preconfigure them before disabling auto range.
        pass

    def _bind_change_tracking(self) -> None:
        self._tracking_ready = False
        variables = [self.mode_var, self.auto_x_var, self.xmin_var, self.xmax_var, self.auto_y_var, self.ymin_var, self.ymax_var,
                     self.ymode_var, self.smoothing_var, self.window_var, self.poly_var, self.sigma_var,
                     self.show_raw_var, self.width_var, self.linestyle_var, self.show_title_var,
                     self.title_template_var, self.legend_template_var, self.legend_title_var,
                     self.auto_title_font_var, self.title_font_var, self.auto_legend_font_var, self.legend_font_var]
        for variable in variables:
            variable.trace_add("write", lambda *_args: self._mark_preview_dirty())
        self.sample_tree.bind("<<TreeviewSelect>>", lambda _e: (self.refresh_mz_list(), self._mark_preview_dirty()), add="+")
        self.mz_list.bind("<<ListboxSelect>>", lambda _e: self._mark_preview_dirty(), add="+")
        self._tracking_ready = True
        self.preview_dirty = True

    def _mark_preview_dirty(self) -> None:
        if not getattr(self, "_tracking_ready", False):
            return
        self.preview_dirty = True
        self.preview_state_var.set("● 有未应用的更改")
        self.preview_state_label.configure(foreground="#A46218")

    def _mark_preview_current(self) -> None:
        self.preview_dirty = False
        self.preview_state_var.set("● 当前预览已更新")
        self.preview_state_label.configure(foreground="#2E7D5B")

    def show_welcome(self) -> None:
        if str(self.welcome_page) not in self.plot_notebook.tabs():
            self.plot_notebook.insert(0, self.welcome_page, text="欢迎")
        self._refresh_recent_list()
        self.plot_notebook.select(self.welcome_page)

    def show_quick_help(self) -> None:
        messagebox.showinfo(
            "快速使用说明",
            "1. 导入或拖入一个或多个 TDS CSV。\n"
            "2. 选择绘图模式、样品和 m/z。\n"
            "3. 展开设置卡片修改坐标、平滑和样式。\n"
            "4. 点击“生成 / 刷新预览”。\n"
            "5. 导出当前图，或进入分峰拟合工作区。\n\n"
            "原始 CSV 始终保持不变。",
            parent=self,
        )

    def _refresh_recent_list(self) -> None:
        if not hasattr(self, "recent_list"):
            return
        self.recent_list.delete(0, "end")
        valid = [path for path in self.preferences.get("recent_projects", []) if Path(path).exists()][:5]
        self.preferences["recent_projects"] = valid
        for path in valid:
            self.recent_list.insert("end", f"{Path(path).name}    —    {Path(path).parent}")

    def _remember_project(self, path: str) -> None:
        resolved = str(Path(path).resolve())
        recent = [item for item in self.preferences.get("recent_projects", []) if str(item).lower() != resolved.lower()]
        self.preferences["recent_projects"] = [resolved, *recent][:5]
        self._save_preferences(); self._refresh_recent_list()

    def open_recent_project(self) -> None:
        selection = self.recent_list.curselection()
        if not selection:
            return
        paths = self.preferences.get("recent_projects", [])
        if selection[0] < len(paths):
            self.open_project(paths[selection[0]])

    def remove_recent_project(self) -> None:
        selection = self.recent_list.curselection()
        if not selection:
            return
        paths = list(self.preferences.get("recent_projects", []))
        if selection[0] < len(paths):
            paths.pop(selection[0])
        self.preferences["recent_projects"] = paths
        self._save_preferences(); self._refresh_recent_list()

    def load_demo_data(self) -> None:
        APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
        demo_paths = []
        for sample_index, shift in enumerate((0.0, 24.0), start=1):
            path = APP_DATA_DIR / f"TDS_Demonstration_{sample_index}.csv"
            rows = ["Demonstration data - synthetic, not experimental", "No real sample information", "", "No.,Time[s],Temperature1[C],Temperature2[C],m/z 2,m/z 18,m/z 28,m/z 44"]
            for index, temperature in enumerate(np.linspace(30, 1200, 420), start=1):
                def peak(center, width, height):
                    return height * math.exp(-0.5 * ((temperature - center - shift) / width) ** 2)
                baseline = 1.2e-15 * (1 + temperature / 1800)
                values = [baseline + peak(390, 42, 8e-11), baseline + peak(535, 70, 3.5e-11), baseline + peak(720, 90, 1.7e-11), baseline + peak(880, 65, 1.1e-11)]
                rows.append(f"{index},{index * 2.0:.1f},{temperature:.4f},{temperature:.4f}," + ",".join(f"{value:.9e}" for value in values))
            path.write_text("\n".join(rows), encoding="utf-8")
            demo_paths.append(str(path))
        self.import_files(demo_paths)
        self.status_var.set("已载入两个明确标注的模拟样品，可用于单样品绘图和横向比较。")

    def import_files(self, paths=None) -> None:
        paths = paths or filedialog.askopenfilenames(title="选择 TDS CSV", filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if not paths:
            return
        errors = []
        imported_samples = []
        saved_templates = list(self.preferences.get("import_templates", []))
        batch_template = None
        existing = {sample.path.lower() for sample in self.samples}
        for path in paths:
            try:
                try:
                    active_templates = ([batch_template] if batch_template else []) + saved_templates
                    sample = parse_tds_csv(path, templates=active_templates)
                except ColumnMappingRequired as mapping_error:
                    dialog = ColumnMappingDialog(self, mapping_error.layout, saved_templates)
                    self.wait_window(dialog)
                    if not dialog.result:
                        continue
                    sample = parse_tds_csv(path, mapping=dialog.result)
                    batch_template = {"name": "本次批量映射", "temperature": dialog.result["temperature"],
                                      "time": dialog.result.get("time"), "mz": dialog.result["mz"]}
                    if dialog.saved_template:
                        saved_templates = [item for item in saved_templates if item.get("name") != dialog.saved_template["name"]]
                        saved_templates = [dialog.saved_template, *saved_templates]
                        self.preferences["import_templates"] = saved_templates
                        self._save_preferences()
                if sample.path.lower() not in existing:
                    self.samples.append(sample)
                    imported_samples.append(sample)
                    existing.add(sample.path.lower())
            except Exception as exc:
                errors.append(f"{Path(path).name}: {exc}")
        self.refresh_sample_tree()
        self.refresh_mz_list()
        detected = "; ".join(f"{Path(s.path).name}: {s.encoding}/{s.delimiter}" + (f"/模板 {s.import_template}" if s.import_template else "") for s in imported_samples)
        self.status_var.set(f"已导入 {len(self.samples)} 个样品。{detected}")
        quality = [f"{Path(sample.path).name}: {warning}" for sample in imported_samples for warning in sample.quality_warnings]
        if quality:
            messagebox.showwarning("数据质量提示", "\n".join(quality[:30]) + ("\n……" if len(quality) > 30 else ""), parent=self)
        if errors:
            messagebox.showwarning("部分文件未导入", "\n".join(errors))

    def refresh_sample_tree(self) -> None:
        self.sample_tree.delete(*self.sample_tree.get_children())
        for i, sample in enumerate(self.samples):
            automatic = sample_curve_color(sample, i)
            self.sample_tree.insert("", "end", iid=str(i), values=(sample.display_name, sample.plot_color or f"自动 {automatic}"))
        if self.samples:
            self.sample_tree.selection_set("0")

    def selected_sample_indices(self) -> list[int]:
        return [int(item) for item in self.sample_tree.selection() if int(item) < len(self.samples)]

    def remove_samples(self) -> None:
        for index in sorted(self.selected_sample_indices(), reverse=True):
            self.samples.pop(index)
        self.refresh_sample_tree()
        self.refresh_mz_list()

    def rename_sample(self, _event=None) -> None:
        selected = self.selected_sample_indices()
        if len(selected) != 1:
            return
        sample = self.samples[selected[0]]
        name = simpledialog.askstring("修改样品名称", "图例中显示的名称：", initialvalue=sample.display_name, parent=self)
        if name and name.strip():
            sample.display_name = name.strip()
            self.refresh_sample_tree()
            self.sample_tree.selection_set(str(selected[0]))

    def on_mode_change(self) -> None:
        self.mz_list.configure(selectmode="extended" if self.mode_var.get() == "single" else "browse")
        self.refresh_mz_list()

    def refresh_mz_list(self) -> None:
        previous = {self.mz_list.get(i) for i in self.mz_list.curselection()}
        self.mz_list.delete(0, "end")
        selected = self.selected_sample_indices()
        if not selected and self.samples:
            selected = [0]
        if not selected:
            return
        common = set(self.samples[selected[0]].mz_columns)
        for index in selected[1:]:
            common &= set(self.samples[index].mz_columns)
        ordered = [mz for mz in self.samples[selected[0]].mz_columns if mz in common]
        for mz in ordered:
            self.mz_list.insert("end", mz)
        defaults = previous or {"m/z 2", "m/z 18", "m/z 28", "m/z 44"}
        for i, mz in enumerate(ordered):
            if mz in defaults:
                self.mz_list.selection_set(i)
        if self.mode_var.get() == "compare" and self.mz_list.curselection():
            first = self.mz_list.curselection()[0]
            self.mz_list.selection_clear(0, "end")
            self.mz_list.selection_set(first)

    def choose_color(self) -> None:
        color = colorchooser.askcolor(color=self.settings.color, title="选择单样品曲线颜色", parent=self)[1]
        if color:
            self.settings.color = color
            self.color_button.configure(text=color.upper())
            self._mark_preview_dirty()

    def choose_sample_color(self) -> None:
        indices = self.selected_sample_indices()
        if not indices:
            messagebox.showinfo("曲线颜色", "请先在样品列表中选择一个或多个样品。", parent=self)
            return
        initial = self.samples[indices[0]].plot_color or PALETTE[indices[0] % len(PALETTE)]
        color = colorchooser.askcolor(color=initial, title="设置所选样品曲线颜色", parent=self)[1]
        if not color:
            return
        for index in indices:
            self.samples[index].plot_color = color.upper()
        self.refresh_sample_tree()
        for index in indices:
            self.sample_tree.selection_add(str(index))
        self.refresh_mz_list()
        self._mark_preview_dirty()

    def reset_sample_colors(self) -> None:
        indices = self.selected_sample_indices()
        if not indices:
            messagebox.showinfo("曲线颜色", "请先选择要恢复自动配色的样品。", parent=self)
            return
        for index in indices:
            self.samples[index].plot_color = None
        self.refresh_sample_tree()
        for index in indices:
            self.sample_tree.selection_add(str(index))
        self.refresh_mz_list()
        self._mark_preview_dirty()

    def open_peak_fitting(self) -> None:
        if not self.samples:
            messagebox.showinfo("分峰拟合", "请先导入至少一个 TDS CSV 文件。", parent=self)
            return
        from peak_fitting_ui import PeakFittingWindow
        PeakFittingWindow(self)

    def selected_mz(self) -> list[str]:
        return [self.mz_list.get(i) for i in self.mz_list.curselection()]

    def clear_pages(self) -> None:
        for tab in self.plot_notebook.tabs():
            self.plot_notebook.forget(tab)
        self.pages.clear()

    def _new_figure(self) -> tuple[Figure, object]:
        figure = Figure(figsize=(7.2, 5.2), dpi=110, layout="constrained")
        ax = figure.subplots()
        return figure, ax

    def generate_plots(self) -> None:
        try:
            settings = self._read_settings()
            indices = self.selected_sample_indices()
            mz_values = self.selected_mz()
            if not indices:
                raise ValueError("请先选择至少一个样品。")
            if not mz_values:
                raise ValueError("请至少选择一个 m/z。")
            if self.mode_var.get() == "single" and len(indices) != 1:
                raise ValueError("单样品模式请只选择一个样品。")
            if self.mode_var.get() == "compare" and len(mz_values) != 1:
                raise ValueError("横向比较模式请只选择一个 m/z。")
            self.settings = settings
            self.clear_pages()
            if self.mode_var.get() == "single":
                self._plot_single(self.samples[indices[0]], mz_values)
            else:
                self._plot_compare([self.samples[i] for i in indices], mz_values[0])
            self.status_var.set(f"已生成 {len(self.pages)} 张图。平滑：{settings.smoothing}；纵轴：{settings.y_mode}。")
            self._mark_preview_current()
            return True
        except Exception as exc:
            messagebox.showerror("无法生成图形", str(exc), parent=self)
            return False

    def _plot_single(self, sample: TDSData, mz_values: list[str]) -> None:
        for mz in mz_values:
            raw = sample.signal(mz)
            smoothed = smooth_signal(raw, self.settings)
            floor = positive_floor(self.settings, [smoothed, raw])
            plotted, replaced = apply_y_policy(smoothed, self.settings, floor)
            raw_plotted, _ = apply_y_policy(raw, self.settings, floor)
            figure, ax = self._new_figure()
            if self.settings.show_raw and self.settings.smoothing != "None":
                ax.plot(sample.temperature, raw_plotted, color="#999999", lw=0.8, alpha=0.65, label="Raw")
            legend_label = format_plot_text(self.settings.legend_template, mz, sample.display_name, mz)
            title = format_plot_text(self.settings.title_template, f"{sample.display_name} - {mz}", sample.display_name, mz)
            curve_color = sample_curve_color(sample, fallback=self.settings.color)
            ax.plot(sample.temperature, plotted, color=curve_color, lw=self.settings.line_width, ls=self.settings.line_style, label=legend_label)
            configure_axis(ax, self.settings, title)
            apply_data_limits(ax, self.settings, [sample.temperature], [smoothed], [plotted])
            legend_size = automatic_legend_font_size(figure, [legend_label]) if self.settings.auto_legend_font else self.settings.legend_font_size
            ax.legend(loc="best", fontsize=legend_size, title=self.settings.legend_title or None, title_fontsize=legend_size)
            provenance = self._provenance([sample], [mz], floor, replaced)
            self._add_page(figure, mz.replace("/", "_"), provenance, mz)

    def _plot_compare(self, samples: list[TDSData], mz: str) -> None:
        raw_series = [sample.signal(mz) for sample in samples]
        smooth_series = [smooth_signal(y, self.settings) for y in raw_series]
        floor = positive_floor(self.settings, raw_series + smooth_series)
        figure, ax = self._new_figure()
        replaced_total = 0
        plotted_series = []
        custom_labels = [part.strip() for part in re.split(r"[;；]", self.settings.legend_template) if part.strip()]
        for i, (sample, raw, smoothed) in enumerate(zip(samples, raw_series, smooth_series)):
            plotted, replaced = apply_y_policy(smoothed, self.settings, floor)
            plotted_series.append(plotted)
            replaced_total += replaced
            color = sample_curve_color(sample, i)
            linestyle = LINESTYLES[(i // len(PALETTE)) % len(LINESTYLES)]
            if self.settings.show_raw and self.settings.smoothing != "None":
                raw_plotted, _ = apply_y_policy(raw, self.settings, floor)
                ax.plot(sample.temperature, raw_plotted, color=color, lw=0.6, alpha=0.25)
            if i < len(custom_labels):
                label = format_plot_text(custom_labels[i], sample.display_name, sample.display_name, mz)
            else:
                label = sample.display_name
            ax.plot(sample.temperature, plotted, color=color, ls=linestyle, lw=self.settings.line_width, label=label)
        title = format_plot_text(self.settings.title_template, f"Sample comparison - {mz}", "Sample comparison", mz)
        configure_axis(ax, self.settings, title)
        apply_data_limits(ax, self.settings, [sample.temperature for sample in samples], smooth_series, plotted_series)
        labels = [line.get_label() for line in ax.get_lines() if not line.get_label().startswith("_")]
        legend_size = automatic_legend_font_size(figure, labels) if self.settings.auto_legend_font else self.settings.legend_font_size
        ax.legend(loc="best", fontsize=legend_size, title=self.settings.legend_title or None, title_fontsize=legend_size)
        provenance = self._provenance(samples, [mz], floor, replaced_total)
        self._add_page(figure, f"comparison_{mz.replace('/', '_')}", provenance, f"比较 {mz}")

    def _provenance(self, samples: list[TDSData], mz: list[str], floor: float, replaced: int) -> dict:
        return {
            "application": f"{APP_NAME} {APP_VERSION}",
            "source_files": [sample.path for sample in samples],
            "display_names": [sample.display_name for sample in samples],
            "curve_colors": {sample.display_name: (sample.plot_color or "automatic") for sample in samples},
            "x_column": "Temperature1[C]",
            "y_columns": mz,
            "settings": asdict(self.settings),
            "nonpositive_policy": f"Values <= 0 are replaced by {floor:.8g} A for logarithmic display; no source rows are deleted.",
            "replaced_point_count": replaced,
            "smoothing_record": self._smoothing_record(),
        }

    def _smoothing_record(self) -> str:
        s = self.settings
        if s.smoothing == "Savitzky-Golay":
            return f"Savitzky-Golay; window={s.window}; polyorder={s.polyorder}"
        if s.smoothing == "Moving average":
            return f"Moving average; window={s.window}"
        if s.smoothing == "Gaussian":
            return f"Gaussian; sigma={s.gaussian_sigma}"
        return "None"

    def _add_page(self, figure: Figure, key: str, provenance: dict, label: str) -> None:
        page = FigurePage(self.plot_notebook, figure, key, provenance)
        self.pages.append(page)
        self.plot_notebook.add(page, text=label)
        self.plot_notebook.select(page)

    def current_page(self) -> FigurePage | None:
        selected = self.plot_notebook.select()
        for page in self.pages:
            if str(page) == selected:
                return page
        return None

    def export_current(self) -> None:
        page = self.current_page()
        if not page:
            messagebox.showinfo("导出", "请先生成并选择一张图。")
            return
        if self.preview_dirty and not messagebox.askyesno("存在未应用更改", "当前预览尚未应用最新参数。是否仍导出旧预览？", parent=self):
            return
        path = filedialog.asksaveasfilename(title="导出当前图", initialfile=page.key + ".png", defaultextension=".png", filetypes=[("PNG 600 dpi", "*.png"), ("PDF", "*.pdf"), ("SVG", "*.svg")])
        if path:
            self._export_page(page, Path(path))
            messagebox.showinfo("导出完成", f"已导出：\n{path}")

    def export_all(self) -> None:
        if not self.pages:
            messagebox.showinfo("导出", "请先生成图形。")
            return
        folder = filedialog.askdirectory(title="选择导出文件夹")
        if not folder:
            return
        for page in self.pages:
            self._export_page(page, Path(folder) / f"{page.key}.png")
        messagebox.showinfo("导出完成", f"已将 {len(self.pages)} 张图以 PNG 600 dpi 导出到：\n{folder}")

    def _export_page(self, page: FigurePage, path: Path) -> None:
        export_figure(page.figure, path, page.provenance)

    def _smoothing_comparison_figures(self) -> list[dict]:
        if self.settings.smoothing == "None":
            return []
        comparisons = []
        seen = set()
        samples_by_path = {sample.path: sample for sample in self.samples}
        for page in self.pages:
            for source_path in page.provenance.get("source_files", []):
                sample = samples_by_path.get(source_path)
                if not sample:
                    continue
                for mz in page.provenance.get("y_columns", []):
                    key = (source_path, mz)
                    if key in seen or mz not in sample.mz_columns:
                        continue
                    seen.add(key)
                    raw = sample.signal(mz); smoothed = smooth_signal(raw, self.settings)
                    floor = positive_floor(self.settings, [raw, smoothed])
                    raw_plot, _ = apply_y_policy(raw, self.settings, floor); smooth_plot, _ = apply_y_policy(smoothed, self.settings, floor)
                    figure, ax = self._new_figure()
                    ax.plot(sample.temperature, raw_plot, color="#8B98A3", lw=0.8, alpha=0.8, label="Raw")
                    ax.plot(sample.temperature, smooth_plot, color="#1676A8", lw=1.4, label=self.settings.smoothing)
                    comparison_settings = PlotSettings(**asdict(self.settings)); comparison_settings.show_title = True
                    configure_axis(ax, comparison_settings, f"{sample.display_name} - {mz}: raw vs smoothed")
                    apply_data_limits(ax, comparison_settings, [sample.temperature, sample.temperature], [raw, smoothed], [raw_plot, smooth_plot])
                    ax.legend(loc="best")
                    comparisons.append({"label": f"{sample.display_name} - {mz}", "figure": figure, "note": f"平滑方法：{self._smoothing_record()}。灰色为原始数据，蓝色为平滑结果；原始 CSV 未修改。"})
        return comparisons

    def export_analysis_report(self) -> None:
        if not self.samples:
            messagebox.showinfo("分析报告", "请先导入数据。", parent=self); return
        if self.preview_dirty or not self.pages:
            if not self.generate_plots():
                return
        folder = filedialog.askdirectory(title="选择分析报告保存文件夹", parent=self)
        if not folder:
            return
        try:
            from analysis_report import build_analysis_pdf, sha256_file
            generated = datetime.now().astimezone().isoformat(timespec="seconds")
            project_name = Path(self.current_project).stem if self.current_project else "未命名项目"
            sources = [{"filename": Path(sample.path).name, "sha256": sha256_file(sample.path),
                        "points": len(sample.temperature), "mz_count": len(sample.mz_columns)} for sample in self.samples]
            report_pages = [{"label": self.plot_notebook.tab(page, "text"), "figure": page.figure} for page in self.pages]
            fits = []
            for session in self.fit_sessions.values():
                item = dict(session); item["sample_filename"] = Path(item.get("sample_path", "")).name
                item.pop("sample_path", None); fits.append(item)
            base = Path(folder) / f"{project_name}_TDS分析报告"
            pdf_path, json_path = base.with_suffix(".pdf"), base.with_suffix(".json")
            comparisons = self._smoothing_comparison_figures()
            build_analysis_pdf(pdf_path, app_name=APP_NAME, app_version=APP_VERSION, project_name=project_name,
                               sources=sources, settings=asdict(self.settings), plot_pages=report_pages,
                               smoothing_comparisons=comparisons, fit_sessions=fits, generated_at=generated)
            record = {"application": f"{APP_NAME} {APP_VERSION}", "generated_at": generated, "project": project_name,
                      "sources": sources, "settings": asdict(self.settings),
                      "plots": [{"label": item["label"], "provenance": {k: v for k, v in page.provenance.items() if k != "source_files"}} for item, page in zip(report_pages, self.pages)],
                      "fit_sessions": fits, "privacy": "Only source filenames are recorded; local directory paths are omitted."}
            json_path.write_text(json.dumps(record, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
            messagebox.showinfo("报告已生成", f"已生成全部绘图分页、处理记录和分峰汇总：\n{pdf_path}\n{json_path}", parent=self)
        except Exception as exc:
            self._write_log("分析报告生成失败", exc)
            messagebox.showerror("报告生成失败", f"{exc}\n详细信息已写入诊断日志。", parent=self)

    def save_project(self) -> None:
        try:
            self.settings = self._read_settings()
            path = filedialog.asksaveasfilename(title="保存 TDS Plotter 项目", initialfile="TDS_project.tdsplot", defaultextension=".tdsplot", filetypes=[("TDS Plotter project", "*.tdsplot")])
            if not path:
                return
            payload = {
                "format_version": 1,
                "samples": [{"path": s.path, "display_name": s.display_name, "import_mapping": s.import_mapping,
                             "plot_color": s.plot_color} for s in self.samples],
                "settings": asdict(self.settings),
                "mode": self.mode_var.get(),
                "selected_mz": self.selected_mz(),
                "fit_sessions": self.fit_sessions,
            }
            Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            self.current_project = path
            self._remember_project(path)
            self.status_var.set(f"项目已保存：{Path(path).name}")
        except Exception as exc:
            messagebox.showerror("保存失败", str(exc))

    def open_project(self, path=None) -> None:
        path = path or filedialog.askopenfilename(title="打开 TDS Plotter 项目", filetypes=[("TDS Plotter project", "*.tdsplot"), ("All files", "*.*")])
        if not path:
            return
        try:
            payload = json.loads(Path(path).read_text(encoding="utf-8"))
            self._apply_project_payload(payload, path)
        except Exception as exc:
            self._write_log("打开项目失败", exc)
            messagebox.showerror("打开失败", str(exc))

    def _apply_project_payload(self, payload: dict, path: str | None = None) -> None:
            loaded = []
            missing = []
            for item in payload.get("samples", []):
                if not Path(item["path"]).exists():
                    missing.append(item["path"])
                    continue
                sample = parse_tds_csv(item["path"], mapping=item.get("import_mapping"), templates=self.preferences.get("import_templates", []))
                sample.display_name = item.get("display_name", sample.display_name)
                stored_color = item.get("plot_color")
                sample.plot_color = stored_color if stored_color and mpl.colors.is_color_like(stored_color) else None
                loaded.append(sample)
            self.samples = loaded
            allowed = set(PlotSettings.__dataclass_fields__)
            settings = {k: v for k, v in payload.get("settings", {}).items() if k in allowed}
            self.settings = PlotSettings(**settings)
            self.mode_var.set(payload.get("mode", "single"))
            self.fit_sessions = payload.get("fit_sessions", {})
            self.refresh_sample_tree()
            self._sync_controls_from_settings()
            self.on_mode_change()
            wanted = set(payload.get("selected_mz", []))
            self.mz_list.selection_clear(0, "end")
            for i in range(self.mz_list.size()):
                if self.mz_list.get(i) in wanted:
                    self.mz_list.selection_set(i)
            self.current_project = path
            if path:
                self._remember_project(path)
                self.status_var.set(f"项目已打开：{Path(path).name}")
            if missing:
                messagebox.showwarning("缺少源文件", "以下源文件不存在，未载入：\n" + "\n".join(missing))


def main() -> int:
    app = TDSPlotterApp()
    if len(sys.argv) > 1:
        csv_paths = []
        for path in sys.argv[1:]:
            if Path(path).suffix.lower() == ".tdsplot":
                app.open_project(path)
                continue
            csv_paths.append(path)
        if csv_paths:
            app.import_files(csv_paths)
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
