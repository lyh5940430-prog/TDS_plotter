from __future__ import annotations

import hashlib
import io
from datetime import datetime
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _register_chinese_font() -> str:
    candidates = [Path(r"C:\Windows\Fonts\msyh.ttc"), Path(r"C:\Windows\Fonts\simhei.ttf"), Path(r"C:\Windows\Fonts\simsun.ttc")]
    for candidate in candidates:
        if candidate.exists():
            try:
                pdfmetrics.registerFont(TTFont("TDSChinese", str(candidate)))
                return "TDSChinese"
            except Exception:
                continue
    return "Helvetica"


def _figure_image(figure, max_width=17.2 * cm, max_height=11.2 * cm):
    stream = io.BytesIO()
    figure.savefig(stream, format="png", dpi=180, facecolor="white", transparent=False)
    stream.seek(0)
    width, height = figure.get_size_inches()
    scale = min(max_width / width, max_height / height)
    return Image(stream, width=width * scale, height=height * scale)


def build_analysis_pdf(output_path, *, app_name, app_version, project_name, sources, settings,
                       plot_pages, smoothing_comparisons, fit_sessions, generated_at=None):
    font = _register_chinese_font()
    generated_at = generated_at or datetime.now().astimezone().isoformat(timespec="seconds")
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("ChineseTitle", parent=styles["Title"], fontName=font, fontSize=20, leading=26, textColor=colors.HexColor("#173B59"), alignment=TA_CENTER)
    h1 = ParagraphStyle("ChineseH1", parent=styles["Heading1"], fontName=font, fontSize=14, leading=19, textColor=colors.HexColor("#245B82"), spaceBefore=8, spaceAfter=7)
    body = ParagraphStyle("ChineseBody", parent=styles["BodyText"], fontName=font, fontSize=9, leading=14, textColor=colors.HexColor("#283E4E"))
    small = ParagraphStyle("ChineseSmall", parent=body, fontSize=7.5, leading=10)
    doc = SimpleDocTemplate(str(output_path), pagesize=A4, rightMargin=1.6 * cm, leftMargin=1.6 * cm, topMargin=1.5 * cm, bottomMargin=1.5 * cm, title="TDS 分析报告", author=app_name)
    story = [Paragraph("TDS 数据分析报告", title_style), Spacer(1, 0.3 * cm)]

    info = [["项目", project_name], ["生成时间", generated_at], ["软件", f"{app_name} {app_version}"], ["绘图分页", str(len(plot_pages))], ["分峰记录", str(len(fit_sessions))]]
    story += [Table(info, colWidths=[3.2 * cm, 13.5 * cm], style=[("FONTNAME", (0, 0), (-1, -1), font), ("FONTSIZE", (0, 0), (-1, -1), 9), ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#E5F0F7")), ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#B7CBD9")), ("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 6), ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]), Spacer(1, 0.25 * cm)]

    story.append(Paragraph("1. 原始数据与文件指纹", h1))
    source_rows = [["文件名", "SHA-256", "数据点", "m/z 数"]]
    for item in sources:
        source_rows.append([item["filename"], Paragraph(item["sha256"], small), str(item["points"]), str(item["mz_count"])])
    story.append(Table(source_rows, repeatRows=1, colWidths=[4.1 * cm, 9.4 * cm, 1.6 * cm, 1.6 * cm], style=[("FONTNAME", (0, 0), (-1, -1), font), ("FONTSIZE", (0, 0), (-1, -1), 7.5), ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#D7E9F5")), ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#AFC5D4")), ("VALIGN", (0, 0), (-1, -1), "TOP")]))

    story.append(Paragraph("2. 绘图与数据处理设置", h1))
    setting_names = {
        "auto_x": "横轴自动范围", "x_min": "横轴下限 (°C)", "x_max": "横轴上限 (°C)",
        "auto_y": "纵轴自动范围", "y_min": "纵轴下限 (A)", "y_max": "纵轴上限 (A)",
        "y_mode": "纵轴模式", "smoothing": "平滑方法", "window": "平滑窗口",
        "polyorder": "多项式阶数", "gaussian_sigma": "Gaussian σ", "show_raw": "绘图显示原始曲线",
        "line_width": "线宽", "line_style": "线型", "color": "曲线颜色", "show_title": "显示标题",
        "title_template": "标题", "legend_template": "曲线名称", "legend_title": "图例标题",
        "auto_title_font": "标题字号自动", "title_font_size": "标题字号 (pt)",
        "auto_legend_font": "图例字号自动", "legend_font_size": "图例字号 (pt)",
    }
    def display_value(value):
        return "是" if value is True else "否" if value is False else str(value)
    setting_rows = [["参数", "值"]] + [[setting_names.get(str(key), str(key)), display_value(value)] for key, value in settings.items()]
    story.append(Table(setting_rows, repeatRows=1, colWidths=[5.4 * cm, 11.3 * cm], style=[("FONTNAME", (0, 0), (-1, -1), font), ("FONTSIZE", (0, 0), (-1, -1), 8), ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#D7E9F5")), ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#AFC5D4"))]))
    story.append(Paragraph("说明：报告只记录源文件名，不记录本机目录。原始 CSV 未被修改。对数显示、非正值替代和平滑参数以本表及随附 JSON 为准。", body))

    for index, page in enumerate(plot_pages, start=1):
        story += [PageBreak(), Paragraph(f"3.{index} 绘图分页：{page['label']}", h1), _figure_image(page["figure"])]
    for index, item in enumerate(smoothing_comparisons, start=1):
        story += [PageBreak(), Paragraph(f"4.{index} 原始曲线与平滑曲线对照：{item['label']}", h1), _figure_image(item["figure"]), Paragraph(item["note"], body)]

    story += [PageBreak(), Paragraph("5. 分峰拟合汇总", h1)]
    if not fit_sessions:
        story.append(Paragraph("当前项目未进行分峰分析。", body))
    for index, session in enumerate(fit_sessions, start=1):
        summary = session.get("result_summary", {})
        stats = summary.get("statistics", {})
        story.append(Paragraph(f"5.{index} {session.get('sample_name', session.get('sample_filename', '样品'))} - {session.get('mz', '')}", h1))
        story.append(Paragraph(f"峰型：{summary.get('config', {}).get('peak_type', '未记录')}；R²：{stats.get('r_squared', '未记录')}；RMSE：{stats.get('rmse', '未记录')}；BIC：{stats.get('bic', '未记录')}", body))
        peaks = summary.get("peaks", [])
        if peaks:
            rows = [["峰", "Tmax (°C)", "Height (A)", "FWHM (°C)", "Area (A·°C)"]]
            for peak in peaks:
                rows.append([str(peak.get("index", "")), f"{peak.get('center', 0):.3f}", f"{peak.get('height', 0):.5g}", f"{peak.get('fwhm', 0):.3f}", f"{peak.get('area', 0):.5g}"])
            story.append(Table(rows, repeatRows=1, colWidths=[1.4 * cm, 3.2 * cm, 4 * cm, 3.2 * cm, 4.2 * cm], style=[("FONTNAME", (0, 0), (-1, -1), font), ("FONTSIZE", (0, 0), (-1, -1), 8), ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#D7E9F5")), ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#AFC5D4"))]))
        diagnostics = stats.get("diagnostics") or []
        if diagnostics:
            story.append(Paragraph("诊断提示：" + " ".join(diagnostics), body))

    def footer(canvas, document):
        canvas.saveState(); canvas.setFont(font, 7.5); canvas.setFillColor(colors.HexColor("#718798"))
        canvas.drawString(1.6 * cm, 0.75 * cm, f"{app_name} {app_version}")
        canvas.drawRightString(A4[0] - 1.6 * cm, 0.75 * cm, f"第 {document.page} 页")
        canvas.restoreState()
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
