from __future__ import annotations

import csv
import json
from dataclasses import asdict
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

import numpy as np
from PIL import Image
import matplotlib as mpl
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure

from peak_fitting import (
    BASELINE_TYPES,
    PEAK_TYPES,
    WEIGHT_TYPES,
    FitConfig,
    FitResult,
    PeakSpec,
    bootstrap_confidence,
    compare_peak_types,
    detect_peaks,
    fit_peaks,
    suggest_peak_from_residual,
    suggest_complete_peak_range,
    best_residual_peak_trial,
)
from ui_widgets import CollapsibleSection, VerticalScrolledFrame, fit_window_to_screen


FIT_COLORS = ["#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9", "#0072B2", "#000000", "#F0E442"]


def _auto_title_size(figure, text):
    density = len(text) / max(float(figure.get_figwidth()), 1.0)
    return float(np.clip(12.0 - max(density - 5.5, 0.0) * 0.22, 8.0, 12.0))


def _auto_legend_size(figure, labels):
    labels = [str(label) for label in labels]
    density = (max((len(label) for label in labels), default=0) + 4 * max(len(labels) - 1, 0)) / max(float(figure.get_figwidth()), 1.0)
    return float(np.clip(9.5 - max(density - 3.0, 0.0) * 0.16, 7.0, 9.5))


class PeakFittingWindow(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent_app = parent
        self.title("TDS Plotter - 分峰拟合")
        fit_window_to_screen(self, 1500, 900, 920, 560)
        self.peaks: list[PeakSpec] = []
        self.result: FitResult | None = None
        self._click_mode = False
        self._build_ui()
        self._load_samples()

    def _build_ui(self):
        pane = ttk.Panedwindow(self, orient="horizontal")
        pane.pack(fill="both", expand=True, padx=8, pady=8)
        control_scroller = VerticalScrolledFrame(pane, width=405)
        controls = control_scroller.content
        right = ttk.Frame(pane)
        pane.add(control_scroller, weight=0)
        pane.add(right, weight=1)

        source_card = CollapsibleSection(controls, "数据与拟合区间", True); source_card.pack(fill="x", pady=3)
        source = source_card.content
        self.sample_var, self.mz_var = tk.StringVar(), tk.StringVar()
        self.fit_min_var, self.fit_max_var = tk.StringVar(), tk.StringVar()
        self.sample_combo = self._combo_row(source, "样品", self.sample_var, [], 0)
        self.mz_combo = self._combo_row(source, "m/z", self.mz_var, [], 1)
        self.sample_combo.bind("<<ComboboxSelected>>", self._sample_changed)
        self.mz_combo.bind("<<ComboboxSelected>>", lambda _e: self._source_changed())
        range_row = ttk.Frame(source)
        range_row.grid(row=2, column=0, columnspan=2, sticky="ew", padx=6, pady=4)
        ttk.Label(range_row, text="温度范围").pack(side="left")
        ttk.Entry(range_row, textvariable=self.fit_min_var, width=9).pack(side="left", padx=4)
        ttk.Label(range_row, text="至").pack(side="left")
        ttk.Entry(range_row, textvariable=self.fit_max_var, width=9).pack(side="left", padx=4)
        ttk.Button(source, text="建议完整峰拟合范围", command=self.apply_suggested_range).grid(row=3, column=0, columnspan=2, sticky="ew", padx=6, pady=(0, 5))

        model_card = CollapsibleSection(controls, "模型设置", True); model_card.pack(fill="x", pady=3)
        model = model_card.content
        self.peak_type_var = tk.StringVar(value="Pseudo-Voigt")
        self.baseline_var = tk.StringVar(value="None")
        self.weight_var = tk.StringVar(value="None")
        self.display_scale_var = tk.StringVar(value="Linear")
        self.weight_floor_var = tk.StringVar(value="0.01")
        self._combo_row(model, "峰型", self.peak_type_var, PEAK_TYPES, 0)
        self._combo_row(model, "基线", self.baseline_var, BASELINE_TYPES, 1)
        self._combo_row(model, "权重", self.weight_var, WEIGHT_TYPES, 2)
        self._combo_row(model, "显示纵轴", self.display_scale_var, ["Linear", "Log axis"], 3).bind("<<ComboboxSelected>>", lambda _e: self._draw())
        floor_row = ttk.Frame(model)
        floor_row.grid(row=4, column=0, columnspan=2, sticky="ew", padx=6, pady=3)
        ttk.Label(floor_row, text="Custom 权重下限比例").pack(side="left")
        ttk.Entry(floor_row, textvariable=self.weight_floor_var, width=8).pack(side="right")

        detection_card = CollapsibleSection(controls, "自动寻峰", True); detection_card.pack(fill="x", pady=3)
        detection = detection_card.content
        self.prominence_var = tk.StringVar(value="3")
        self.distance_var = tk.StringVar(value="20")
        self.min_width_var = tk.StringVar(value="5")
        self.max_peaks_var = tk.StringVar(value="")
        rows = [
            ("最小突出度 (%信号跨度)", self.prominence_var),
            ("最小峰间距 (°C)", self.distance_var),
            ("最小峰宽 (°C)", self.min_width_var),
            ("最多建议峰数（留空不限）", self.max_peaks_var),
        ]
        for row, (label, variable) in enumerate(rows):
            ttk.Label(detection, text=label).grid(row=row, column=0, sticky="w", padx=6, pady=2)
            ttk.Entry(detection, textvariable=variable, width=9).grid(row=row, column=1, sticky="e", padx=6)
        ttk.Label(detection, text="建议：突出度 1–10%；间距 10–50 °C；最小宽度 5–30 °C", foreground="#555555", wraplength=360).grid(row=4, column=0, columnspan=2, sticky="w", padx=6, pady=4)
        buttons = ttk.Frame(detection)
        buttons.grid(row=5, column=0, columnspan=2, sticky="ew", padx=6, pady=5)
        ttk.Button(buttons, text="自动检测", command=self.auto_detect).pack(side="left", expand=True, fill="x")
        ttk.Button(buttons, text="点击图中添加峰", command=self.enable_click_add).pack(side="left", expand=True, fill="x", padx=(5, 0))

        text_card = CollapsibleSection(controls, "标题与图例", False); text_card.pack(fill="x", pady=3)
        text_box = text_card.content
        self.show_title_var = tk.BooleanVar(value=True)
        self.fit_title_var = tk.StringVar(value="")
        self.observed_label_var = tk.StringVar(value="Observed")
        self.total_label_var = tk.StringVar(value="Total fit")
        self.baseline_label_var = tk.StringVar(value="Baseline")
        self.peak_label_var = tk.StringVar(value="Peak")
        self.auto_title_font_var = tk.BooleanVar(value=True)
        self.auto_legend_font_var = tk.BooleanVar(value=True)
        self.title_font_var = tk.StringVar(value="10")
        self.legend_font_var = tk.StringVar(value="9")
        ttk.Checkbutton(text_box, text="显示标题", variable=self.show_title_var, command=self._draw).grid(row=0, column=0, sticky="w", padx=6)
        fields = [("标题（留空自动）", self.fit_title_var), ("原始曲线", self.observed_label_var),
                  ("总拟合", self.total_label_var), ("基线", self.baseline_label_var), ("分峰前缀", self.peak_label_var)]
        for row_index, (label, variable) in enumerate(fields, start=1):
            ttk.Label(text_box, text=label).grid(row=row_index, column=0, sticky="w", padx=6, pady=2)
            ttk.Entry(text_box, textvariable=variable).grid(row=row_index, column=1, sticky="ew", padx=6, pady=2)
        ttk.Checkbutton(text_box, text="标题字号自动", variable=self.auto_title_font_var, command=self._draw).grid(row=6, column=0, sticky="w", padx=6)
        title_font_entry = ttk.Entry(text_box, textvariable=self.title_font_var, width=7)
        title_font_entry.grid(row=6, column=1, sticky="w", padx=6)
        ttk.Checkbutton(text_box, text="图例字号自动", variable=self.auto_legend_font_var, command=self._draw).grid(row=7, column=0, sticky="w", padx=6)
        legend_font_entry = ttk.Entry(text_box, textvariable=self.legend_font_var, width=7)
        legend_font_entry.grid(row=7, column=1, sticky="w", padx=6, pady=(0, 4))
        for entry, variable in ((title_font_entry, self.auto_title_font_var), (legend_font_entry, self.auto_legend_font_var)):
            entry.bind("<KeyRelease>", lambda _e, v=variable: (v.set(False), self._draw()))
            entry.bind("<<Paste>>", lambda _e, v=variable: self.after_idle(lambda: (v.set(False), self._draw())))
        text_box.columnconfigure(1, weight=1)

        peak_card = CollapsibleSection(controls, "峰参数（双击编辑）", True); peak_card.pack(fill="x", pady=3)
        peak_box = peak_card.content
        columns = ("id", "center", "height", "fwhm", "locks")
        self.peak_tree = ttk.Treeview(peak_box, columns=columns, show="headings", height=8, selectmode="browse")
        labels = {"id": "峰", "center": "Tmax", "height": "高度", "fwhm": "FWHM", "locks": "锁定"}
        widths = {"id": 35, "center": 65, "height": 85, "fwhm": 60, "locks": 85}
        for column in columns:
            self.peak_tree.heading(column, text=labels[column])
            self.peak_tree.column(column, width=widths[column], anchor="center")
        self.peak_tree.pack(fill="both", expand=True, padx=5, pady=5)
        self.peak_tree.bind("<Double-1>", self.edit_selected_peak)
        row = ttk.Frame(peak_box)
        row.pack(fill="x", padx=5, pady=(0, 5))
        ttk.Button(row, text="编辑", command=self.edit_selected_peak).pack(side="left", expand=True, fill="x")
        ttk.Button(row, text="删除", command=self.delete_selected_peak).pack(side="left", expand=True, fill="x", padx=4)
        ttk.Button(row, text="清空", command=self.clear_peaks).pack(side="left", expand=True, fill="x")

        action_card = CollapsibleSection(controls, "拟合与输出", True); action_card.pack(fill="x", pady=3)
        action = action_card.content
        ttk.Button(action, text="开始拟合", command=self.run_fit, style="Primary.TButton").pack(fill="x", padx=6, pady=(6, 2))
        ttk.Button(action, text="智能残差补峰（BIC 验证）", command=self.add_residual_peak).pack(fill="x", padx=6, pady=2)
        row = ttk.Frame(action)
        row.pack(fill="x", padx=6, pady=2)
        ttk.Button(row, text="比较三种峰型", command=self.compare_models).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Bootstrap", command=self.run_bootstrap).pack(side="left", fill="x", expand=True, padx=(5, 0))
        row2 = ttk.Frame(action)
        row2.pack(fill="x", padx=6, pady=2)
        ttk.Button(row2, text="批量样品拟合", command=self.batch_fit).pack(side="left", fill="x", expand=True)
        ttk.Button(row2, text="导出结果", command=self.export_results).pack(side="left", fill="x", expand=True, padx=(5, 0))
        self.status_var = tk.StringVar(value="选择样品和 m/z 后自动检测峰。")
        ttk.Label(action, textvariable=self.status_var, foreground="#444444", wraplength=360).pack(fill="x", padx=6, pady=5)

        self.figure = Figure(figsize=(8.2, 6.4), dpi=100, layout="constrained")
        axes = self.figure.subplots(2, 1, sharex=True, gridspec_kw={"height_ratios": [3.2, 1]})
        self.fit_ax, self.residual_ax = axes
        self.canvas = FigureCanvasTkAgg(self.figure, master=right)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill="both", expand=True)
        toolbar = NavigationToolbar2Tk(self.canvas, right, pack_toolbar=False)
        toolbar.update(); toolbar.pack(fill="x")
        self.canvas.mpl_connect("button_press_event", self._on_plot_click)

        stats = ttk.LabelFrame(right, text="拟合结果")
        stats.pack(fill="x", pady=(5, 0))
        result_columns = ("id", "center", "center_ci", "height", "fwhm", "area")
        self.result_tree = ttk.Treeview(stats, columns=result_columns, show="headings", height=5)
        result_labels = {"id": "峰", "center": "Tmax (°C)", "center_ci": "95% CI", "height": "Height (A)", "fwhm": "FWHM (°C)", "area": "Area (A·°C)"}
        for column in result_columns:
            self.result_tree.heading(column, text=result_labels[column])
            self.result_tree.column(column, width=125 if column != "id" else 40, anchor="center")
        self.result_tree.pack(fill="x", padx=5, pady=5)

    def _combo_row(self, parent, label, variable, values, row):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=6, pady=3)
        combo = ttk.Combobox(parent, textvariable=variable, values=list(values), state="readonly", width=27)
        combo.grid(row=row, column=1, sticky="ew", padx=6, pady=3)
        parent.columnconfigure(1, weight=1)
        return combo

    def _load_samples(self):
        names = [sample.display_name for sample in self.parent_app.samples]
        self.sample_combo.configure(values=names)
        if names:
            self.sample_var.set(names[0])
            self._sample_changed()
        else:
            self.status_var.set("主界面尚未导入样品。")

    def _sample(self):
        index = self.sample_combo.current()
        return self.parent_app.samples[index] if 0 <= index < len(self.parent_app.samples) else None

    def _sample_changed(self, _event=None):
        sample = self._sample()
        if not sample:
            return
        self.mz_combo.configure(values=sample.mz_columns)
        preferred = "m/z 18" if "m/z 18" in sample.mz_columns else sample.mz_columns[0]
        self.mz_var.set(preferred)
        self.fit_min_var.set(f"{float(np.min(sample.temperature)):.2f}")
        self.fit_max_var.set(f"{float(np.max(sample.temperature)):.2f}")
        self._source_changed()

    def _source_changed(self):
        self.result = None
        key = self._session_key()
        saved = getattr(self.parent_app, "fit_sessions", {}).get(key)
        if saved:
            self.peaks = [PeakSpec(**item) for item in saved.get("initial_peaks", [])]
            config = saved.get("config", {})
            self.peak_type_var.set(config.get("peak_type", self.peak_type_var.get()))
            self.baseline_var.set(config.get("baseline_type", self.baseline_var.get()))
            self.weight_var.set(config.get("weighting", self.weight_var.get()))
            self.fit_min_var.set(str(saved.get("fit_min", self.fit_min_var.get())))
            self.fit_max_var.set(str(saved.get("fit_max", self.fit_max_var.get())))
            plot_text = saved.get("plot_text", {})
            self.show_title_var.set(plot_text.get("show_title", True))
            self.fit_title_var.set(plot_text.get("title", ""))
            self.observed_label_var.set(plot_text.get("observed", "Observed"))
            self.total_label_var.set(plot_text.get("total", "Total fit"))
            self.baseline_label_var.set(plot_text.get("baseline", "Baseline"))
            self.peak_label_var.set(plot_text.get("peak_prefix", "Peak"))
            self.auto_title_font_var.set(plot_text.get("auto_title_font", True))
            self.title_font_var.set(str(plot_text.get("title_font_size", 10)))
            self.auto_legend_font_var.set(plot_text.get("auto_legend_font", True))
            self.legend_font_var.set(str(plot_text.get("legend_font_size", 9)))
        else:
            self.peaks = []
        self._refresh_peak_tree(); self._draw()
        self._show_boundary_hint()

    def _show_boundary_hint(self):
        try:
            sample = self._sample()
            _, _, notes = suggest_complete_peak_range(sample.temperature, sample.signal(self.mz_var.get()))
            if notes:
                self.status_var.set(" ".join(notes) + " 可点击“建议完整峰拟合范围”应用；原始数据不会被修改。")
        except Exception:
            pass

    def apply_suggested_range(self):
        try:
            sample = self._sample()
            low, high, notes = suggest_complete_peak_range(sample.temperature, sample.signal(self.mz_var.get()))
            self.fit_min_var.set(f"{low:.3f}")
            self.fit_max_var.set(f"{high:.3f}")
            self.peaks = []
            self.result = None
            self._refresh_peak_tree(); self._draw()
            self.status_var.set((" ".join(notes) if notes else "未检测到明显的边界截断峰，保留完整温度范围。") + " 请重新自动检测峰。")
        except Exception as exc:
            messagebox.showerror("范围建议失败", str(exc), parent=self)

    def _session_key(self):
        sample = self._sample()
        return f"{sample.path}|{self.mz_var.get()}" if sample else ""

    def _xy(self):
        sample = self._sample()
        if sample is None or self.mz_var.get() not in sample.mz_columns:
            raise ValueError("请选择有效的样品和 m/z。")
        low, high = float(self.fit_min_var.get()), float(self.fit_max_var.get())
        if low >= high:
            raise ValueError("拟合温度下限必须小于上限。")
        x, y = sample.temperature, sample.signal(self.mz_var.get())
        mask = np.isfinite(x) & np.isfinite(y) & (x >= low) & (x <= high)
        if np.count_nonzero(mask) < 5:
            raise ValueError("拟合区间内的数据点不足。")
        return x[mask], y[mask]

    def _config(self, tolerance=None):
        return FitConfig(
            peak_type=self.peak_type_var.get(), baseline_type=self.baseline_var.get(),
            weighting=self.weight_var.get(), custom_weight_floor=float(self.weight_floor_var.get()),
            center_tolerance=tolerance,
        )

    def auto_detect(self):
        try:
            x, y = self._xy()
            maximum = int(self.max_peaks_var.get()) if self.max_peaks_var.get().strip() else None
            self.peaks = detect_peaks(x, y, float(self.prominence_var.get()), float(self.distance_var.get()), float(self.min_width_var.get()), maximum)
            self.result = None
            self._refresh_peak_tree(); self._draw()
            self.status_var.set(f"自动建议 {len(self.peaks)} 个峰；请检查并人工增删或修改。")
        except Exception as exc:
            messagebox.showerror("自动寻峰失败", str(exc), parent=self)

    def enable_click_add(self):
        self._click_mode = True
        self.status_var.set("请在上方曲线中单击要添加的峰位。")

    def _on_plot_click(self, event):
        if not self._click_mode or event.inaxes is not self.fit_ax or event.xdata is None:
            return
        try:
            x, y = self._xy()
            index = int(np.argmin(np.abs(x - event.xdata)))
            baseline = float(np.percentile(y, 5))
            height = max(float(y[index] - baseline), float(np.ptp(y)) * 0.02)
            self.peaks.append(PeakSpec(float(x[index]), height, max(float(self.min_width_var.get()) * 2, 10.0)))
            self.peaks.sort(key=lambda peak: peak.center)
            self._click_mode = False
            self.result = None
            self._refresh_peak_tree(); self._draw()
            self.status_var.set("已添加峰。双击参数表可精确修改。")
        except Exception as exc:
            messagebox.showerror("添加失败", str(exc), parent=self)

    def _refresh_peak_tree(self):
        self.peak_tree.delete(*self.peak_tree.get_children())
        for i, peak in enumerate(self.peaks):
            locks = "/".join(name for name, locked in [("T", peak.locked_center), ("H", peak.locked_height), ("W", peak.locked_fwhm)] if locked) or "—"
            self.peak_tree.insert("", "end", iid=str(i), values=(i + 1, f"{peak.center:.2f}", f"{peak.height:.4g}", f"{peak.fwhm:.2f}", locks))

    def edit_selected_peak(self, _event=None):
        selection = self.peak_tree.selection()
        if not selection:
            return
        index = int(selection[0]); peak = self.peaks[index]
        dialog = PeakEditDialog(self, peak)
        self.wait_window(dialog)
        if dialog.result:
            self.peaks[index] = dialog.result
            self.peaks.sort(key=lambda item: item.center)
            self.result = None; self._refresh_peak_tree(); self._draw()

    def delete_selected_peak(self):
        selection = self.peak_tree.selection()
        if selection:
            self.peaks.pop(int(selection[0])); self.result = None; self._refresh_peak_tree(); self._draw()

    def clear_peaks(self):
        self.peaks.clear(); self.result = None; self._refresh_peak_tree(); self._draw()

    def run_fit(self):
        try:
            x, y = self._xy()
            self.result = fit_peaks(x, y, self.peaks, self._config())
            self.peaks = [PeakSpec(p.center, p.height, p.fwhm, eta=p.eta or 0.5) for p in self.result.peaks]
            self._refresh_peak_tree(); self._show_result(); self._save_session()
            status = f"拟合完成：R²={self.result.r_squared:.6f}，RMSE={self.result.rmse:.3g}，BIC={self.result.bic:.2f}"
            if self.result.diagnostics:
                status += "\n诊断：" + " ".join(self.result.diagnostics)
            self.status_var.set(status)
        except Exception as exc:
            messagebox.showerror("拟合失败", str(exc), parent=self)

    def add_residual_peak(self):
        if not self.result:
            messagebox.showinfo("残差补峰", "请先完成一次拟合。", parent=self)
            return
        try:
            suggestion, trial, improvement = best_residual_peak_trial(self.result, float(self.distance_var.get()), float(self.min_width_var.get()))
            if suggestion is None or trial is None:
                messagebox.showinfo("残差补峰", "没有检测到满足当前间距和宽度条件的明显正残差峰。", parent=self)
                return
            if improvement <= 2.0:
                messagebox.showinfo(
                    "不建议补峰",
                    f"候选峰约位于 {suggestion.center:.2f} °C，但加入后 BIC 改善仅为 {improvement:.2f}（需要 >2）。\n软件未添加该峰，以避免追随噪声。",
                    parent=self,
                )
                return
            self.result = trial
            self.peaks = [PeakSpec(p.center, p.height, p.fwhm, eta=p.eta or 0.5) for p in trial.peaks]
            self._refresh_peak_tree(); self._show_result(); self._save_session()
            self.status_var.set(f"已接受 {suggestion.center:.2f} °C 附近的残差峰：BIC 改善 {improvement:.2f}，新 R²={trial.r_squared:.6f}。")
        except Exception as exc:
            messagebox.showerror("残差补峰失败", str(exc), parent=self)

    def compare_models(self):
        try:
            x, y = self._xy()
            results = compare_peak_types(x, y, self.peaks, self._config())
            window = tk.Toplevel(self); window.title("峰型方案比较")
            tree = ttk.Treeview(window, columns=("rank", "type", "aic", "bic", "adjr2", "rmse"), show="headings", height=6)
            for column, label in [("rank", "排名"), ("type", "峰型"), ("aic", "AIC"), ("bic", "BIC"), ("adjr2", "调整 R²"), ("rmse", "RMSE")]:
                tree.heading(column, text=label); tree.column(column, width=110, anchor="center")
            for i, item in enumerate(results):
                tree.insert("", "end", values=(i + 1, item.config.peak_type, f"{item.aic:.2f}", f"{item.bic:.2f}", f"{item.adjusted_r_squared:.6f}", f"{item.rmse:.3g}"))
            tree.pack(padx=8, pady=8)
            ttk.Label(window, text="BIC/AIC 越小越好；仍需结合残差、峰形物理意义和跨样品一致性决定。", wraplength=650).pack(padx=8, pady=(0, 8))
        except Exception as exc:
            messagebox.showerror("模型比较失败", str(exc), parent=self)

    def run_bootstrap(self):
        if not self.result:
            messagebox.showinfo("Bootstrap", "请先完成一次拟合。", parent=self); return
        count = simpledialog.askinteger("Bootstrap", "重采样次数（建议快速 100，正式结果 500–1000）：", initialvalue=200, minvalue=20, maxvalue=5000, parent=self)
        if not count:
            return
        try:
            self.status_var.set(f"Bootstrap 0/{count}…")
            def progress(done, total):
                if done == total or done % max(1, total // 20) == 0:
                    self.status_var.set(f"Bootstrap {done}/{total}…"); self.update_idletasks()
            self.result = bootstrap_confidence(self.result, self.peaks, count, progress=progress)
            self._show_result(); self._save_session()
            self.status_var.set(f"Bootstrap 完成：{self.result.bootstrap_samples}/{count} 次有效拟合。")
        except Exception as exc:
            messagebox.showerror("Bootstrap 失败", str(exc), parent=self)

    def _draw(self):
        self.fit_ax.clear(); self.residual_ax.clear()
        try:
            x, y = self._xy()
        except Exception:
            self.canvas.draw_idle(); return
        observed_label = self.observed_label_var.get().strip() or "Observed"
        total_label = self.total_label_var.get().strip() or "Total fit"
        baseline_label = self.baseline_label_var.get().strip() or "Baseline"
        peak_prefix = self.peak_label_var.get().strip() or "Peak"
        self.fit_ax.plot(x, y, color="#555555", lw=1.0, label=observed_label)
        if self.result:
            for i, component in enumerate(self.result.components):
                curve = component + self.result.baseline if len(self.result.components) == 1 else component
                self.fit_ax.plot(self.result.x, curve, color=FIT_COLORS[i % len(FIT_COLORS)], ls="--", lw=1.1, label=f"{peak_prefix} {i + 1}")
            if self.baseline_var.get() != "None":
                self.fit_ax.plot(self.result.x, self.result.baseline, color="#777777", ls=":", lw=1.0, label=baseline_label)
            self.fit_ax.plot(self.result.x, self.result.total_fit, color="#000000", lw=1.8, label=total_label)
            self.residual_ax.plot(self.result.x, self.result.residual, color="#0072B2", lw=0.9)
        else:
            baseline = float(np.percentile(y, 5))
            for i, peak in enumerate(self.peaks):
                self.fit_ax.axvline(peak.center, color=FIT_COLORS[i % len(FIT_COLORS)], ls="--", lw=1.0)
                self.fit_ax.text(peak.center, baseline + peak.height, f"P{i + 1}", color=FIT_COLORS[i % len(FIT_COLORS)], ha="center", va="bottom")
        if self.display_scale_var.get() == "Log axis":
            positive = y[y > 0]
            floor = (float(np.min(positive)) / 10) if positive.size else 1e-16
            self.fit_ax.set_yscale("log")
            low, high = self.fit_ax.get_ylim(); self.fit_ax.set_ylim(max(low, floor), high)
        handles, labels = self.fit_ax.get_legend_handles_labels()
        try:
            legend_size = _auto_legend_size(self.figure, labels) if self.auto_legend_font_var.get() else float(self.legend_font_var.get())
            title_size = _auto_title_size(self.figure, self.fit_title_var.get()) if self.auto_title_font_var.get() else float(self.title_font_var.get())
            if not (6 <= legend_size <= 36 and 6 <= title_size <= 36):
                raise ValueError
        except ValueError:
            legend_size, title_size = 9.0, 10.0
        self.fit_ax.set_ylabel("Ion current (A)"); self.fit_ax.legend(handles, labels, loc="best", ncol=2, fontsize=legend_size)
        self.residual_ax.axhline(0, color="black", lw=0.7)
        self.residual_ax.set(xlabel=r"Temperature ($^{\circ}$C)", ylabel="Residual (A)")
        self.fit_ax.set_xlim(float(np.min(x)), float(np.max(x)))
        x_formatter = mpl.ticker.ScalarFormatter(useOffset=False)
        x_formatter.set_scientific(False)
        self.residual_ax.xaxis.set_major_formatter(x_formatter)
        title = self.fit_title_var.get().strip() or f"{self.sample_var.get()} - {self.mz_var.get()} peak deconvolution"
        if self.show_title_var.get():
            if self.auto_title_font_var.get():
                title_size = _auto_title_size(self.figure, title)
            self.fit_ax.set_title(title, fontsize=title_size, pad=8)
        self.canvas.draw_idle()

    def _show_result(self):
        self._draw(); self.result_tree.delete(*self.result_tree.get_children())
        if not self.result:
            return
        for peak in self.result.peaks:
            ci = peak.center_ci95
            ci_text = f"[{ci[0]:.2f}, {ci[1]:.2f}]" if ci else "—"
            self.result_tree.insert("", "end", values=(peak.index, f"{peak.center:.2f}", ci_text, f"{peak.height:.5g}", f"{peak.fwhm:.2f}", f"{peak.area:.5g}"))

    def _save_session(self):
        if not self.result:
            return
        payload = {
            "sample_path": self._sample().path, "mz": self.mz_var.get(),
            "sample_name": self.sample_var.get(),
            "fit_min": float(self.fit_min_var.get()), "fit_max": float(self.fit_max_var.get()),
            "config": asdict(self.result.config), "initial_peaks": [asdict(peak) for peak in self.peaks],
            "result_summary": self.result.summary_dict(),
            "plot_text": {
                "show_title": self.show_title_var.get(), "title": self.fit_title_var.get(),
                "observed": self.observed_label_var.get(), "total": self.total_label_var.get(),
                "baseline": self.baseline_label_var.get(), "peak_prefix": self.peak_label_var.get(),
                "auto_title_font": self.auto_title_font_var.get(), "title_font_size": self.title_font_var.get(),
                "auto_legend_font": self.auto_legend_font_var.get(), "legend_font_size": self.legend_font_var.get(),
            },
        }
        self.parent_app.fit_sessions[self._session_key()] = payload

    def export_results(self):
        if not self.result:
            messagebox.showinfo("导出", "请先完成拟合。", parent=self); return
        folder = filedialog.askdirectory(title="选择分峰拟合结果文件夹", parent=self)
        if not folder:
            return
        sample_name = "".join(c if c.isalnum() or c in "-_" else "_" for c in self.sample_var.get())
        mz_name = self.mz_var.get().replace("/", "_").replace(" ", "")
        base = Path(folder) / f"{sample_name}_{mz_name}_peak_fit"
        with base.with_suffix(".csv").open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.writer(handle)
            writer.writerow(["Temperature[C]", "Observed[A]", "TotalFit[A]", "Baseline[A]", *[f"Peak{i+1}[A]" for i in range(len(self.result.components))], "Residual[A]"])
            for row in zip(self.result.x, self.result.observed, self.result.total_fit, self.result.baseline, *self.result.components, self.result.residual):
                writer.writerow([f"{float(row[0]):.6f}", *row[1:]])
        record = self.result.summary_dict()
        record["source_file"] = self._sample().path
        record["sample_name"] = self.sample_var.get()
        record["mz"] = self.mz_var.get()
        record["fit_range_celsius"] = [float(self.fit_min_var.get()), float(self.fit_max_var.get())]
        base.with_suffix(".json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
        for suffix in (".png", ".pdf", ".svg"):
            output = base.with_suffix(suffix)
            self.figure.savefig(output, dpi=600.02 if suffix == ".png" else 300, facecolor="white", transparent=False)
            if suffix == ".png":
                with Image.open(output) as image:
                    rgb = Image.new("RGB", image.size, "white")
                    if image.mode == "RGBA":
                        rgb.paste(image, mask=image.getchannel("A"))
                    else:
                        rgb.paste(image.convert("RGB"))
                    rgb.save(output, format="PNG", dpi=(600.02, 600.02), optimize=True)
        self.status_var.set(f"结果已导出到：{folder}")

    def batch_fit(self):
        if not self.result:
            messagebox.showinfo("批量拟合", "请先在参考样品上完成拟合。", parent=self); return
        mz = self.mz_var.get()
        candidates = [sample for sample in self.parent_app.samples if mz in sample.mz_columns]
        if len(candidates) < 2:
            messagebox.showinfo("批量拟合", "至少需要两个包含相同 m/z 的样品。", parent=self); return
        tolerances = {}
        for sample in candidates:
            value = simpledialog.askfloat("峰位容差", f"{sample.display_name}\n相对参考峰位允许移动 ±多少 °C？\n输入 0 表示固定峰位。", initialvalue=20.0, minvalue=0.0, parent=self)
            if value is None:
                return
            tolerances[sample.path] = value
        folder = filedialog.askdirectory(title="选择批量拟合结果文件夹", parent=self)
        if not folder:
            return
        rows = []
        for sample_index, sample in enumerate(candidates):
            tolerance = tolerances[sample.path]
            specs = [PeakSpec(p.center, p.height, p.fwhm, locked_center=tolerance == 0, eta=p.eta or 0.5) for p in self.result.peaks]
            x, y = sample.temperature, sample.signal(mz)
            low, high = float(self.fit_min_var.get()), float(self.fit_max_var.get())
            mask = np.isfinite(x) & np.isfinite(y) & (x >= low) & (x <= high)
            try:
                fitted = fit_peaks(x[mask], y[mask], specs, self._config(tolerance if tolerance > 0 else None))
                for peak in fitted.peaks:
                    rows.append([sample.display_name, f"{tolerance:.2f}", fitted.config.peak_type, peak.index, f"{peak.center:.6f}", f"{peak.fwhm:.6f}", peak.height, peak.area, fitted.r_squared, fitted.bic, "OK"])
            except Exception as exc:
                rows.append([sample.display_name, tolerance, self.peak_type_var.get(), "", "", "", "", "", "", "", str(exc)])
            self.status_var.set(f"批量拟合 {sample_index + 1}/{len(candidates)}…"); self.update_idletasks()
        output = Path(folder) / f"batch_{mz.replace('/', '_').replace(' ', '')}_peak_summary.csv"
        with output.open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.writer(handle); writer.writerow(["Sample", "CenterTolerance[C]", "PeakType", "Peak", "Tmax[C]", "FWHM[C]", "Height[A]", "Area[A*C]", "R2", "BIC", "Status"]); writer.writerows(rows)
        self.status_var.set(f"批量拟合完成：{output.name}")
        messagebox.showinfo("批量拟合完成", f"结果已保存：\n{output}", parent=self)


class PeakEditDialog(tk.Toplevel):
    def __init__(self, parent, peak: PeakSpec):
        super().__init__(parent); self.title("编辑峰参数"); self.transient(parent); self.grab_set(); self.result = None
        self.center = tk.StringVar(value=f"{peak.center:.2f}"); self.height = tk.StringVar(value=f"{peak.height:g}"); self.fwhm = tk.StringVar(value=f"{peak.fwhm:.2f}")
        self.lock_center = tk.BooleanVar(value=peak.locked_center); self.lock_height = tk.BooleanVar(value=peak.locked_height); self.lock_fwhm = tk.BooleanVar(value=peak.locked_fwhm); self.eta = peak.eta
        for row, (label, variable, locked) in enumerate([("Tmax (°C)", self.center, self.lock_center), ("Height (A)", self.height, self.lock_height), ("FWHM (°C)", self.fwhm, self.lock_fwhm)]):
            ttk.Label(self, text=label).grid(row=row, column=0, padx=8, pady=5, sticky="w"); ttk.Entry(self, textvariable=variable, width=16).grid(row=row, column=1, padx=8); ttk.Checkbutton(self, text="锁定", variable=locked).grid(row=row, column=2, padx=8)
        row = ttk.Frame(self); row.grid(row=3, column=0, columnspan=3, sticky="ew", padx=8, pady=8)
        ttk.Button(row, text="确定", command=self.accept).pack(side="left", expand=True, fill="x"); ttk.Button(row, text="取消", command=self.destroy).pack(side="left", expand=True, fill="x", padx=(5, 0))

    def accept(self):
        try:
            center, height, fwhm = float(self.center.get()), float(self.height.get()), float(self.fwhm.get())
            if height <= 0 or fwhm <= 0:
                raise ValueError("峰高和 FWHM 必须大于零。")
            self.result = PeakSpec(center, height, fwhm, self.lock_center.get(), self.lock_height.get(), self.lock_fwhm.get(), self.eta); self.destroy()
        except Exception as exc:
            messagebox.showerror("参数错误", str(exc), parent=self)
