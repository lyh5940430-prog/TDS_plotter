from __future__ import annotations

import tkinter as tk
from tkinter import ttk


def fit_window_to_screen(
    window: tk.Misc,
    preferred_width: int,
    preferred_height: int,
    minimum_width: int = 900,
    minimum_height: int = 560,
) -> None:
    """Size and center a window without exceeding the usable screen area."""
    window.update_idletasks()
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()
    available_width = max(640, screen_width - 40)
    # Leave room for the Windows title bar and taskbar, including high-DPI setups.
    available_height = max(480, screen_height - 100)
    width = min(preferred_width, available_width)
    height = min(preferred_height, available_height)
    x = max(0, (screen_width - width) // 2)
    y = max(0, (screen_height - height) // 2 - 15)
    window.geometry(f"{width}x{height}+{x}+{y}")
    window.minsize(min(minimum_width, width), min(minimum_height, height))


class VerticalScrolledFrame(ttk.Frame):
    """A vertically scrollable ttk frame with mouse-wheel support."""

    def __init__(self, master, width: int = 360, **kwargs):
        super().__init__(master, **kwargs)
        self.canvas = tk.Canvas(self, width=width, highlightthickness=0, borderwidth=0)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        self.content = ttk.Frame(self.canvas)
        self._window_id = self.canvas.create_window((0, 0), window=self.content, anchor="nw")
        self.content.bind("<Configure>", self._update_scroll_region)
        self.canvas.bind("<Configure>", self._resize_content)
        self.canvas.bind("<Enter>", self._bind_mousewheel)
        self.canvas.bind("<Leave>", self._unbind_mousewheel)
        self.content.bind("<Enter>", self._bind_mousewheel)
        self.content.bind("<Leave>", self._unbind_mousewheel)

    def _update_scroll_region(self, _event=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _resize_content(self, event):
        self.canvas.itemconfigure(self._window_id, width=event.width)

    def _bind_mousewheel(self, _event=None):
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)

    def _unbind_mousewheel(self, _event=None):
        self.canvas.unbind_all("<MouseWheel>")

    def _on_mousewheel(self, event):
        if self.canvas.winfo_exists():
            self.canvas.yview_scroll(int(-event.delta / 120), "units")


class CollapsibleSection(ttk.Frame):
    """Lightweight card with a keyboard-accessible expandable body."""

    def __init__(self, master, title: str, expanded: bool = True, **kwargs):
        super().__init__(master, style="Card.TFrame", **kwargs)
        self.expanded = tk.BooleanVar(value=expanded)
        self.header = ttk.Button(self, command=self.toggle, style="CardHeader.TButton")
        self.header.pack(fill="x")
        self.content = ttk.Frame(self, style="Card.TFrame", padding=(8, 5, 8, 8))
        self._title = title
        self._render()

    def toggle(self):
        self.expanded.set(not self.expanded.get())
        self._render()

    def _render(self):
        self.header.configure(text=("▼  " if self.expanded.get() else "▶  ") + self._title)
        if self.expanded.get():
            self.content.pack(fill="x")
        else:
            self.content.pack_forget()
