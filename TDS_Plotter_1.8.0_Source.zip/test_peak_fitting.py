import unittest

import numpy as np

from peak_fitting import FitConfig, PeakSpec, best_residual_peak_trial, compare_peak_types, detect_peaks, fit_peaks, gaussian, suggest_complete_peak_range, suggest_peak_from_residual


class PeakFittingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.x = np.linspace(50, 800, 500)
        cls.y = gaussian(cls.x, 250, 4e-11, 75) + gaussian(cls.x, 520, 2e-11, 110) + 2e-12

    def test_auto_detection_finds_two_peaks(self):
        peaks = detect_peaks(self.x, self.y, prominence_percent=5, min_distance_temperature=80, min_width_temperature=10)
        self.assertEqual(len(peaks), 2)
        self.assertAlmostEqual(peaks[0].center, 250, delta=10)
        self.assertAlmostEqual(peaks[1].center, 520, delta=10)

    def test_gaussian_fit_recovers_parameters(self):
        specs = [PeakSpec(245, 3.5e-11, 65), PeakSpec(530, 1.8e-11, 100)]
        result = fit_peaks(self.x, self.y, specs, FitConfig(peak_type="Gaussian", baseline_type="Constant"))
        self.assertTrue(result.success)
        self.assertAlmostEqual(result.peaks[0].center, 250, delta=1)
        self.assertAlmostEqual(result.peaks[1].center, 520, delta=1)
        self.assertGreater(result.r_squared, 0.999)

    def test_model_comparison_returns_all_peak_types(self):
        specs = [PeakSpec(250, 4e-11, 75), PeakSpec(520, 2e-11, 110)]
        results = compare_peak_types(self.x, self.y, specs, FitConfig(baseline_type="Constant"))
        self.assertEqual(len(results), 3)
        self.assertEqual(results[0].config.peak_type, "Gaussian")

    def test_residual_peak_suggestion_finds_missing_peak(self):
        result = fit_peaks(self.x, self.y, [PeakSpec(250, 4e-11, 75)], FitConfig(peak_type="Gaussian", baseline_type="Constant"))
        suggestion = suggest_peak_from_residual(result, min_distance_temperature=50, min_width_temperature=10)
        self.assertIsNotNone(suggestion)
        self.assertAlmostEqual(suggestion.center, 520, delta=15)

    def test_best_residual_trial_improves_bic(self):
        result = fit_peaks(self.x, self.y, [PeakSpec(250, 4e-11, 75)], FitConfig(peak_type="Gaussian", baseline_type="Constant"))
        suggestion, trial, improvement = best_residual_peak_trial(result, min_distance_temperature=50, min_width_temperature=10)
        self.assertIsNotNone(suggestion)
        self.assertIsNotNone(trial)
        self.assertGreater(improvement, 2)
        self.assertAlmostEqual(trial.peaks[-1].center, 520, delta=15)

    def test_boundary_peak_is_diagnosed(self):
        x = np.linspace(0, 100, 200)
        y = gaussian(x, 100, 1.0, 20)
        result = fit_peaks(x, y, [PeakSpec(100, 1.0, 20, locked_center=True)], FitConfig(peak_type="Gaussian"))
        self.assertTrue(any("边界" in item for item in result.diagnostics))

    def test_incomplete_rising_right_edge_suggests_shorter_range(self):
        x = np.linspace(0, 1000, 400)
        y = gaussian(x, 300, 1.0, 90) + gaussian(x, 1150, 0.8, 220) + 0.02
        low, high, notes = suggest_complete_peak_range(x, y)
        self.assertEqual(low, 0.0)
        self.assertLess(high, 1000.0)
        self.assertTrue(any("右边界" in note for note in notes))


if __name__ == "__main__":
    unittest.main()
